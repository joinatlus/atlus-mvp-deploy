"use strict";(()=>{var e={};e.id=255,e.ids=[255],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},1212:e=>{e.exports=require("async_hooks")},4770:e=>{e.exports=require("crypto")},2048:e=>{e.exports=require("fs")},2615:e=>{e.exports=require("http")},8791:e=>{e.exports=require("https")},5315:e=>{e.exports=require("path")},8621:e=>{e.exports=require("punycode")},6162:e=>{e.exports=require("stream")},7360:e=>{e.exports=require("url")},1764:e=>{e.exports=require("util")},2623:e=>{e.exports=require("worker_threads")},1568:e=>{e.exports=require("zlib")},3757:e=>{e.exports=import("prettier/plugins/html")},5747:e=>{e.exports=import("prettier/standalone")},7561:e=>{e.exports=require("node:fs")},4492:e=>{e.exports=require("node:stream")},2477:e=>{e.exports=require("node:stream/web")},8590:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>U,patchFetch:()=>J,requestAsyncStorage:()=>M,routeModule:()=>C,serverHooks:()=>K,staticGenerationAsyncStorage:()=>G});var i={};r.r(i),r.d(i,{GET:()=>H,POST:()=>B,maxDuration:()=>j});var n=r(9303),a=r(8716),s=r(670),o=r(7070),l=r(9064),d=Object.defineProperty,c=Object.defineProperties,u=Object.getOwnPropertyDescriptors,p=Object.getOwnPropertySymbols,h=Object.prototype.hasOwnProperty,m=Object.prototype.propertyIsEnumerable,f=(e,t,r)=>t in e?d(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,y=(e,t)=>{for(var r in t||(t={}))h.call(t,r)&&f(e,r,t[r]);if(p)for(var r of p(t))m.call(t,r)&&f(e,r,t[r]);return e},g=(e,t)=>c(e,u(t)),x=(e,t,r)=>new Promise((i,n)=>{var a=e=>{try{o(r.next(e))}catch(e){n(e)}},s=e=>{try{o(r.throw(e))}catch(e){n(e)}},o=e=>e.done?i(e.value):Promise.resolve(e.value).then(a,s);o((r=r.apply(e,t)).next())}),b=class{constructor(e){this.resend=e}create(e){return x(this,arguments,function*(e,t={}){return yield this.resend.post("/api-keys",e,t)})}list(){return x(this,null,function*(){return yield this.resend.get("/api-keys")})}remove(e){return x(this,null,function*(){return yield this.resend.delete(`/api-keys/${e}`)})}},_=class{constructor(e){this.resend=e}create(e){return x(this,arguments,function*(e,t={}){return yield this.resend.post("/audiences",e,t)})}list(){return x(this,null,function*(){return yield this.resend.get("/audiences")})}get(e){return x(this,null,function*(){return yield this.resend.get(`/audiences/${e}`)})}remove(e){return x(this,null,function*(){return yield this.resend.delete(`/audiences/${e}`)})}};function w(e){var t;return{attachments:null==(t=e.attachments)?void 0:t.map(e=>({content:e.content,filename:e.filename,path:e.path,content_type:e.contentType,inline_content_id:e.inlineContentId})),bcc:e.bcc,cc:e.cc,from:e.from,headers:e.headers,html:e.html,reply_to:e.replyTo,scheduled_at:e.scheduledAt,subject:e.subject,tags:e.tags,text:e.text,to:e.to}}var v=class{constructor(e){this.resend=e}send(e){return x(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return x(this,arguments,function*(e,t={}){let i=[];for(let t of e){if(t.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(44).then(r.bind(r,7044));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}t.html=yield this.renderAsync(t.react),t.react=void 0}i.push(w(t))}return yield this.resend.post("/emails/batch",i,t)})}},A=class{constructor(e){this.resend=e}create(e){return x(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(44).then(r.bind(r,7044));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/broadcasts",{name:e.name,audience_id:e.audienceId,preview_text:e.previewText,from:e.from,html:e.html,reply_to:e.replyTo,subject:e.subject,text:e.text},t)})}send(e,t){return x(this,null,function*(){return yield this.resend.post(`/broadcasts/${e}/send`,{scheduled_at:null==t?void 0:t.scheduledAt})})}list(){return x(this,null,function*(){return yield this.resend.get("/broadcasts")})}get(e){return x(this,null,function*(){return yield this.resend.get(`/broadcasts/${e}`)})}remove(e){return x(this,null,function*(){return yield this.resend.delete(`/broadcasts/${e}`)})}update(e,t){return x(this,null,function*(){return yield this.resend.patch(`/broadcasts/${e}`,{name:t.name,audience_id:t.audienceId,from:t.from,html:t.html,text:t.text,subject:t.subject,reply_to:t.replyTo,preview_text:t.previewText})})}},k=class{constructor(e){this.resend=e}create(e){return x(this,arguments,function*(e,t={}){return yield this.resend.post(`/audiences/${e.audienceId}/contacts`,{unsubscribed:e.unsubscribed,email:e.email,first_name:e.firstName,last_name:e.lastName},t)})}list(e){return x(this,null,function*(){return yield this.resend.get(`/audiences/${e.audienceId}/contacts`)})}get(e){return x(this,null,function*(){return e.id||e.email?yield this.resend.get(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}update(e){return x(this,null,function*(){return e.id||e.email?yield this.resend.patch(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`,{unsubscribed:e.unsubscribed,first_name:e.firstName,last_name:e.lastName}):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}remove(e){return x(this,null,function*(){return e.id||e.email?yield this.resend.delete(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}},$=class{constructor(e){this.resend=e}create(e){return x(this,arguments,function*(e,t={}){return yield this.resend.post("/domains",{name:e.name,region:e.region,custom_return_path:e.customReturnPath},t)})}list(){return x(this,null,function*(){return yield this.resend.get("/domains")})}get(e){return x(this,null,function*(){return yield this.resend.get(`/domains/${e}`)})}update(e){return x(this,null,function*(){return yield this.resend.patch(`/domains/${e.id}`,{click_tracking:e.clickTracking,open_tracking:e.openTracking,tls:e.tls})})}remove(e){return x(this,null,function*(){return yield this.resend.delete(`/domains/${e}`)})}verify(e){return x(this,null,function*(){return yield this.resend.post(`/domains/${e}/verify`)})}},E=class{constructor(e){this.resend=e}send(e){return x(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return x(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(44).then(r.bind(r,7044));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/emails",w(e),t)})}get(e){return x(this,null,function*(){return yield this.resend.get(`/emails/${e}`)})}update(e){return x(this,null,function*(){return yield this.resend.patch(`/emails/${e.id}`,{scheduled_at:e.scheduledAt})})}cancel(e){return x(this,null,function*(){return yield this.resend.post(`/emails/${e}/cancel`)})}},F="undefined"!=typeof process&&process.env&&process.env.RESEND_BASE_URL||"https://api.resend.com",S="undefined"!=typeof process&&process.env&&process.env.RESEND_USER_AGENT||"resend-node:4.8.0",q=class{constructor(e){if(this.key=e,this.apiKeys=new b(this),this.audiences=new _(this),this.batch=new v(this),this.broadcasts=new A(this),this.contacts=new k(this),this.domains=new $(this),this.emails=new E(this),!e&&("undefined"!=typeof process&&process.env&&(this.key=process.env.RESEND_API_KEY),!this.key))throw Error('Missing API key. Pass it to the constructor `new Resend("re_123")`');this.headers=new Headers({Authorization:`Bearer ${this.key}`,"User-Agent":S,"Content-Type":"application/json"})}fetchRequest(e){return x(this,arguments,function*(e,t={}){try{let r=yield fetch(`${F}${e}`,t);if(!r.ok)try{let e=yield r.text();return{data:null,error:JSON.parse(e)}}catch(t){if(t instanceof SyntaxError)return{data:null,error:{name:"application_error",message:"Internal server error. We are unable to process your request right now, please try again later."}};let e={message:r.statusText,name:"application_error"};if(t instanceof Error)return{data:null,error:g(y({},e),{message:t.message})};return{data:null,error:e}}return{data:yield r.json(),error:null}}catch(e){return{data:null,error:{name:"application_error",message:"Unable to fetch data. The request could not be resolved."}}}})}post(e,t){return x(this,arguments,function*(e,t,r={}){let i=new Headers(this.headers);r.idempotencyKey&&i.set("Idempotency-Key",r.idempotencyKey);let n=y({method:"POST",headers:i,body:JSON.stringify(t)},r);return this.fetchRequest(e,n)})}get(e){return x(this,arguments,function*(e,t={}){let r=y({method:"GET",headers:this.headers},t);return this.fetchRequest(e,r)})}put(e,t){return x(this,arguments,function*(e,t,r={}){let i=y({method:"PUT",headers:this.headers,body:JSON.stringify(t)},r);return this.fetchRequest(e,i)})}patch(e,t){return x(this,arguments,function*(e,t,r={}){let i=y({method:"PATCH",headers:this.headers,body:JSON.stringify(t)},r);return this.fetchRequest(e,i)})}delete(e,t){return x(this,null,function*(){let r={method:"DELETE",headers:this.headers,body:JSON.stringify(t)};return this.fetchRequest(e,r)})}},D=r(1964),I=r(3129);function T(e){return e.replace(/[&<>\"]/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[e]||e)}function R(e,t){return`<a href="${e}" style="color:#D45124;text-decoration:none;font-size:13px;line-height:20px;font-weight:600;white-space:nowrap;">${t}</a>`}async function N(e,t){if(!process.env.RESEND_API_KEY)throw Error("RESEND_API_KEY is not configured");return new q(process.env.RESEND_API_KEY).emails.send({from:process.env.EMAIL_FROM||"Atlus <hello@joinatlus.com>",to:e,subject:"Atlus: Worth Your Time Today",html:function(e){let t=(0,D.T)(),r=e.map(e=>{var r;let i={userId:e.user_id,articleId:e.article_id,recommendationItemId:e.id,recommendationRunId:e.recommendation_run_id,surface:"email"},n=(0,I.IS)(i),a=(0,I.ED)({...i,feedbackType:"good_pick"}),s=(0,I.ED)({...i,feedbackType:"not_for_me"}),o=(0,I.ED)({...i,feedbackType:"save"}),l=(0,I.Vi)(i),d=T(e.article.title),c=T(e.article.publisher_name),u=T(e.explanation_text||"Chosen because it matches your current reading profile."),p=T("core"===(r=e.slot_type)?"For you":"stretch"===r?"Go deeper":"discovery"===r?"Something different":String(r)),h=null!=e.article.reading_time_minutes?`&nbsp;&middot;&nbsp;${e.article.reading_time_minutes} min read`:"";return`
      <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;margin:0 0 18px 0;border-collapse:separate;background:#FFFFFF;border:1px solid #DCE1E5;border-radius:16px;">
        <tr>
          <td class="card-pad" style="padding:26px 28px 22px 28px;">
            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0">
              <tr>
                <td style="padding:0 0 14px 0;">
                  <span style="display:inline-block;padding:5px 9px;border-radius:999px;background:#FFF0E9;color:#D45124;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:14px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;">${p}</span>
                </td>
              </tr>
              <tr>
                <td style="padding:0;">
                  <h2 class="article-title" style="margin:0 0 10px 0;font-family:Georgia,'Times New Roman',serif;font-size:25px;line-height:31px;font-weight:700;color:#0F2236;letter-spacing:-.01em;">${d}</h2>
                  <p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:20px;color:#66717D;">${c}${h}</p>
                </td>
              </tr>
              <tr>
                <td style="padding:22px 0 0 0;">
                  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;">
                    <tr>
                      <td style="width:3px;background:#E85D2A;border-radius:3px;" width="3">&nbsp;</td>
                      <td style="padding:0 0 0 14px;">
                        <p style="margin:0 0 5px 0;font-family:Arial,Helvetica,sans-serif;font-size:10px;line-height:14px;font-weight:700;letter-spacing:.10em;text-transform:uppercase;color:#D45124;">Why this one</p>
                        <p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:23px;color:#566370;">${u}</p>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
              <tr>
                <td style="padding:24px 0 0 0;">
                  <table role="presentation" cellspacing="0" cellpadding="0" border="0">
                    <tr>
                      <td bgcolor="#0F2236" style="border-radius:8px;">
                        <a href="${t}/r/${n}" style="display:inline-block;padding:11px 16px;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:18px;font-weight:700;color:#ffffff;text-decoration:none;border-radius:8px;">Read article&nbsp;&rarr;</a>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td class="feedback-pad" style="padding:13px 28px;background:#FAFBF9;border-top:1px solid #E6EAED;border-radius:0 0 16px 16px;">
            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0">
              <tr>
                <td class="feedback-label" style="padding:0 14px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:20px;color:#66717D;white-space:nowrap;">Was this a good pick?</td>
                <td class="feedback-links" align="right" style="font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:20px;color:#A5ADB4;">
                  ${R(`${t}/f/${a}`,"Yes")}
                  <span style="padding:0 7px;color:#A5ADB4;">\xb7</span>
                  ${R(`${t}/f/${s}`,"No")}
                  <span style="padding:0 7px;color:#A5ADB4;">\xb7</span>
                  ${R(`${t}/f/${o}`,"Save")}
                  <span style="padding:0 7px;color:#A5ADB4;">\xb7</span>
                  ${R(`${t}/feedback/more/${l}`,"More")}
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>`}).join(""),i="";if(e[0]){let r=e[0],n=(0,I.F9)({userId:r.user_id,recommendationRunId:r.recommendation_run_id,feedbackType:"slate_great",surface:"email"}),a=(0,I.F9)({userId:r.user_id,recommendationRunId:r.recommendation_run_id,feedbackType:"slate_okay",surface:"email"}),s=(0,I.F9)({userId:r.user_id,recommendationRunId:r.recommendation_run_id,feedbackType:"slate_poor",surface:"email"});i=`
      <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;margin:28px 0 0 0;border-collapse:separate;background:#FFFFFF;border:1px solid #DCE1E5;border-radius:16px;">
        <tr>
          <td align="center" style="padding:20px 18px;">
            <p style="margin:0 0 12px 0;font-family:Georgia,'Times New Roman',serif;font-size:18px;line-height:24px;font-weight:700;color:#0F2236;">How was today&rsquo;s selection?</p>
            <p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:22px;">
              ${R(`${t}/f/${n}`,"Great")}
              <span style="padding:0 12px;color:#A5ADB4;">\xb7</span>
              ${R(`${t}/f/${a}`,"Okay")}
              <span style="padding:0 12px;color:#A5ADB4;">\xb7</span>
              ${R(`${t}/f/${s}`,"Poor")}
            </p>
          </td>
        </tr>
      </table>`}return`<!doctype html>
<html lang="en-GB">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="x-apple-disable-message-reformatting">
  <meta name="format-detection" content="telephone=no,address=no,email=no,date=no,url=no">
  <title>Atlus: Worth Your Time Today</title>
  <style>
    body { margin: 0 !important; padding: 0 !important; }
    table { border-spacing: 0; }
    img { border: 0; }
    a { text-decoration: none; }
    @media only screen and (max-width: 620px) {
      .outer-pad { padding: 24px 14px !important; }
      .header-pad { padding: 0 2px 22px 2px !important; }
      .card-pad { padding: 22px 20px 19px 20px !important; }
      .feedback-pad { padding: 13px 20px !important; }
      .article-title { font-size: 22px !important; line-height: 28px !important; }
      .feedback-label,
      .feedback-links { display: block !important; width: 100% !important; text-align: left !important; }
      .feedback-label { padding: 0 0 4px 0 !important; }
    }
  </style>
</head>
<body style="margin:0;padding:0;background:#F5F6F3;color:#0F2236;">
  <div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent;">A small set of articles chosen to be worth your time today.</div>
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#F5F6F3" style="width:100%;background:#F5F6F3;">
    <tr>
      <td class="outer-pad" align="center" style="padding:38px 18px;">
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:640px;">
          <tr>
            <td class="header-pad" style="padding:0 4px 26px 4px;">
              <p style="margin:0 0 18px 0;font-family:Georgia,'Times New Roman',serif;font-size:24px;line-height:28px;font-weight:700;color:#0F2236;">Atl<span style="color:#E85D2A;font-style:italic;font-weight:400;">u</span>s</p>
              <h1 style="margin:0 0 10px 0;font-family:Georgia,'Times New Roman',serif;font-size:34px;line-height:40px;font-weight:700;letter-spacing:-.02em;color:#0F2236;">Worth your time today.</h1>
              <p style="margin:0;max-width:560px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:23px;color:#66717D;">A small set of recommendations chosen around what you care about, what you want to learn and what might widen your view.</p>
            </td>
          </tr>
          <tr>
            <td>${r}</td>
          </tr>
          <tr>
            <td>${i}</td>
          </tr>
          <tr>
            <td align="center" style="padding:26px 10px 8px 10px;">
              <p style="margin:0 0 8px 0;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:18px;color:#7A848E;">Atlus chooses a few articles each day instead of giving you another feed.</p>
              <p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:20px;color:#7A848E;">
                <a href="${t}/today" style="color:#D45124;text-decoration:underline;">Open Atlus</a>
                <span style="padding:0 8px;color:#A5ADB4;">\xb7</span>
                <a href="${t}/settings" style="color:#D45124;text-decoration:underline;">Settings</a>
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`}(t)})}var O=r(8895);async function P(){let e=(0,l.R)(),{data:t,error:r}=await e.from("profiles").select("id,email,user_profiles!inner(onboarding_status,delivery_time,timezone)").eq("user_profiles.onboarding_status","complete").eq("account_status","active");if(r)throw r;let i=[];for(let r of t||[]){let t=r.user_profiles,n=Array.isArray(t)?t[0]:t,a=function(e,t=new Date){let r=new Intl.DateTimeFormat("en-CA",{timeZone:e,year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hourCycle:"h23"}).formatToParts(t),i=e=>r.find(t=>t.type===e)?.value||"";return{date:`${i("year")}-${i("month")}-${i("day")}`,minutes:60*Number(i("hour"))+Number(i("minute"))}}(n?.timezone||"Europe/London");if(!function(e,t){let[r,i]=e.split(":").map(Number),n=(Number.isFinite(r)?r:8)*60+(Number.isFinite(i)?i:0);return t>=n&&t<n+180}(String(n?.delivery_time||"08:00"),a.minutes)){i.push({user_id:r.id,skipped:"not_due"});continue}let{data:s}=await e.from("email_deliveries").select("*").eq("user_id",r.id).eq("local_delivery_date",a.date).maybeSingle();if(s?.status==="sent"){i.push({user_id:r.id,skipped:"already_sent"});continue}try{let t=s?.recommendation_run_id;t||(t=(await (0,O.G)(e,r.id)).id),await e.from("email_deliveries").upsert({user_id:r.id,recommendation_run_id:t,local_delivery_date:a.date,status:"pending",error_message:null,updated_at:new Date().toISOString()},{onConflict:"user_id,local_delivery_date"});let{data:n}=await e.from("recommendation_items_view").select("*").eq("recommendation_run_id",t).order("rank_position");if(!n?.length||!r.email){await e.from("email_deliveries").update({status:"skipped",error_message:r.email?"No recommendations":"No email address",updated_at:new Date().toISOString()}).eq("user_id",r.id).eq("local_delivery_date",a.date),i.push({user_id:r.id,sent:!1,reason:r.email?"no_items":"no_email"});continue}let o=await N(r.email,n);if(o?.error)throw Error(o.error.message||"Email provider returned an error");await e.from("email_deliveries").update({status:"sent",provider_message_id:o?.data?.id||null,updated_at:new Date().toISOString()}).eq("user_id",r.id).eq("local_delivery_date",a.date),i.push({user_id:r.id,sent:!0,run_id:t})}catch(t){await e.from("email_deliveries").upsert({user_id:r.id,local_delivery_date:a.date,status:"failed",error_message:t?.message||String(t),updated_at:new Date().toISOString()},{onConflict:"user_id,local_delivery_date"}),i.push({user_id:r.id,error:t?.message||String(t)})}}return{ok:!0,results:i}}let j=60;async function z(e){let t=process.env.CRON_SECRET,r=e.headers.get("authorization")?.replace("Bearer ","");return t&&r===t?o.NextResponse.json(await P()):o.NextResponse.json({error:"Unauthorised"},{status:401})}async function H(e){return z(e)}async function B(e){return z(e)}let C=new n.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/cron/daily-email/route",pathname:"/api/cron/daily-email",filename:"route",bundlePath:"app/api/cron/daily-email/route"},resolvedPagePath:"/Users/henry/Downloads/atlus-mvp-free-deploy-clean/app/api/cron/daily-email/route.ts",nextConfigOutput:"standalone",userland:i}),{requestAsyncStorage:M,staticGenerationAsyncStorage:G,serverHooks:K}=C,U="/api/cron/daily-email/route";function J(){return(0,s.patchFetch)({serverHooks:K,staticGenerationAsyncStorage:G})}},3129:(e,t,r)=>{r.d(t,{ED:()=>d,F9:()=>p,IS:()=>c,Vi:()=>u,WX:()=>o});var i=r(4770),n=r.n(i);function a(){return process.env.SIGNING_SECRET||"dev-secret-change-me"}function s(e){var t;let r=(t=JSON.stringify(e),Buffer.from(t).toString("base64url")),i=n().createHmac("sha256",a()).update(r).digest("base64url");return`${r}.${i}`}function o(e){let[t,r]=e.split(".");if(!t||!r)throw Error("Malformed token");let i=n().createHmac("sha256",a()).update(t).digest("base64url"),s=Buffer.from(r),o=Buffer.from(i);if(s.length!==o.length||!n().timingSafeEqual(s,o))throw Error("Invalid token signature");let l=JSON.parse(Buffer.from(t,"base64url").toString("utf8"));if(l.expiresAt<Math.floor(Date.now()/1e3))throw Error("Expired token");return l}function l(e,t=2592e3){return{...e,expiresAt:Math.floor(Date.now()/1e3)+t}}function d(e){return s(l({...e,kind:"feedback"}))}function c(e){return s(l({...e,kind:"read"}))}function u(e){return s(l({...e,kind:"more"}))}function p(e){return d({...e,articleId:null,recommendationItemId:null})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[276,212,214,972,481,837,280],()=>r(8590));module.exports=i})();