"use strict";exports.id=280,exports.ids=[280],exports.modules={1964:(e,t,i)=>{function r(){return"https://joinatlus.com"}function a(e){let t=process.env[e];if(!t)throw Error(`Missing required environment variable: ${e}`);return t}i.d(t,{O:()=>a,T:()=>r})},8895:(e,t,i)=>{i.d(t,{G:()=>c});var r=i(837),a=i(4214);async function n(e){let t=new Map(e.map(e=>[e.article.id,e.fallback]));if(!e.length||!process.env.OPENAI_API_KEY)return t;let i=e.map(e=>{let t=(e.article.concepts||[]).slice(0,8),i=Number(e.features.preferenceFit||0),r=Number(e.features.goalFit||0),a="discovery"===e.slot?i>=r?e.features.matchedPreference||e.features.matchedGoal||null:e.features.matchedGoal||e.features.matchedPreference||null:null;return{article_id:e.article.id,slot:e.slot,title:e.article.title,subtitle:e.article.subtitle,publisher:e.article.publisher_name,summary:e.summary||null,concepts:t,primary_topic:e.article.primary_topic,article_type:e.article.article_type,complexity_level:e.article.complexity_level,matched_interest:e.features.matchedPreference||null,matched_goal:e.features.matchedGoal||null,goal_knowledge_level:e.features.goalKnowledgeLevel??null,goal_learning_mode:e.features.goalLearningMode||null,discovery_anchor:a,discovery_article_topic:"discovery"===e.slot&&(e.article.primary_topic||t[0])||null,recommendation_reasons:e.reasonCodes}}),r=`Locale: en-GB.
Write Atlus's short "Why this one" explanation for each already-selected article.

These explanations do NOT decide what gets recommended.The ranking has already happened.Your job is only to explain the real selection reason clearly, specifically and naturally.

A good "Why this one" is not a summary.

A summary says what the article discusses.
    A "Why this one" explains what this particular reader stands to gain from reading it.

If your draft could plausibly serve as the article's subtitle or generic description, rewrite it.

GENERAL RULES:
  - Exactly one sentence per article.
- Aim for 12 - 22 words and never exceed 26 words.
- Be specific about what the article covers and why that is useful to this reader.
- Ground every claim only in the supplied title, subtitle, summary, concepts and recommendation signals.
- Never invent article content, arguments, conclusions, facts or user preferences.
- Do not simply restate the headline.
- Do not mention "the algorithm", "embedding", "score", "matches your profile", "Core", "Stretch" or "Discovery".
- Avoid promotional language such as "perfect", "must-read", "you'll love", "fascinating" or "essential".
- For political, legal or contested subjects, explain relevance or learning value neutrally.Do not tell the reader what view to hold.
- Avoid generic or formulaic language.
- Do not merely say that a connection exists.State what the substantive connection actually is.
- Prefer explaining the mechanism, theme, concept, institution, historical link, artistic technique, case study or intellectual bridge that makes the article useful.
- If the supplied information is too thin to support a specific connection, stay conservative rather than inventing one.
- Vary sentence structure across articles.

NEVER USE PHRASES SUCH AS:
  - "relevant to your interests"
    - "connects to your interest"
    - "aligns with your goals"
    - "offers a unique perspective"
    - "explores the intersection of"
    - "starting from..."
    - "given your interest in..."
    - "this connects..."
    - "this links..."

  CORE:
  - Explain why this article is especially pertinent to something the reader already cares about.
- Identify the specific angle, development, mechanism or case that makes it worth their attention.
- Do not merely say that it matches an interest.
- Answer: "Why is this especially relevant to something I already care about?"

  STRETCH:
  - Do not merely describe what the article is about.
- Explain what the reader is likely to understand better after reading it, specifically in relation to their learning goal.
- Focus on the learning payoff: the concept, mechanism, distinction, case study or perspective the article can add.
- Make the connection to the exact learning goal concrete when the supplied information supports it.
- Do not simply mention the learning goal; explain the concrete progress this article can support.
- Take the supplied knowledge level and learning mode into account where relevant.
- Answer: "How does reading this move me forward on what I want to learn?"

  DISCOVERY:
  - Do not merely summarise the article.
- Explain the unfamiliar lens, subject or perspective that makes the article a worthwhile departure from the reader's normal reading.
    - Use discovery_anchor as the familiar starting point when supplied.
- Identify the less - familiar subject, lens or perspective using the supplied article information.
  - Explain how that unfamiliar angle extends, reframes, complicates or broadens something the reader already cares about.
- Integrate the familiar bridge naturally into the sentence rather than mechanically naming the user's interest category at the start.
    - Do not use a repeated template such as "Starting from X..."
      - If the explanation could be shown unchanged to a random reader, it is not personalised enough.
- Answer: "What does this expose me to that I probably would not have chosen myself, and why is that useful?"

For Discovery, the underlying structure should usually be:
familiar anchor -> unfamiliar lens -> useful intellectual payoff

Do not copy that structure mechanically into the wording.

Return JSON only in exactly this shape:
  { "explanations": [{ "article_id": "...", "text": "..." }] }

  Articles:
${JSON.stringify(i,null,2)}`;try{let i=new a.ZP({apiKey:process.env.OPENAI_API_KEY}),n=await i.chat.completions.create({model:process.env.OPENAI_EXPLANATION_MODEL||process.env.OPENAI_CLASSIFICATION_MODEL||"gpt-4o-mini",messages:[{role:"system",content:"You write concise, factual recommendation rationales. Return valid JSON only and never invent unsupported content."},{role:"user",content:r}],response_format:{type:"json_object"},temperature:1}),o=n.choices[0]?.message?.content;if(!o)return t;let s=JSON.parse(o);if(!Array.isArray(s.explanations))return t;let l=new Set(e.map(e=>e.article.id));for(let e of s.explanations){let i=String(e?.article_id||"");if(!l.has(i))continue;let r=function(e){if("string"!=typeof e)return null;let t=e.replace(/^why (?:this one|atlus chose it)\s*:\s*/i,"").replace(/\s+/g," ").trim();if(!t)return null;let i=t.split(/\s+/).filter(Boolean);return i.length<7||i.length>26||/\b(score|embedding|algorithm|rank(?:ing)?|cosine|model score)\b/i.test(t)?null:t}(e?.text);r&&t.set(i,r)}}catch(e){console.warn("Atlus explanation generation failed; using deterministic explanations.",e)}return t}let o="recommender_v1.4_feedback_v2_ready";function s(e){if(!e)return null;if(Array.isArray(e)){let t=e.map(Number).filter(Number.isFinite);return t.length?t:null}if("string"==typeof e){let t=e.trim();if(!t||"[]"===t)return null;try{let e=JSON.parse(t);if(Array.isArray(e)){let t=e.map(Number).filter(Number.isFinite);return t.length?t:null}}catch{let e=t.replace(/^\[/,"").replace(/\]$/,"").split(",").map(e=>Number(e.trim())).filter(Number.isFinite);return e.length?e:null}}return null}async function l(e,t,i){let{data:r,error:a}=await e.from("user_recommendation_embeddings").select("embedding_kind,embedding").eq("user_id",t).eq("embedding_version","v1");if(a)throw a;let n=new Map;for(let e of r||[])n.set(String(e.embedding_kind),s(e.embedding));let o=i.filter(e=>e.active&&"goal"===e.assumption_type),l=[];if(o.length){let{data:t,error:i}=await e.from("user_assumption_embeddings").select("assumption_id,embedding_kind,embedding").in("assumption_id",o.map(e=>e.id)).eq("embedding_version","v1");if(i)throw i;let r=new Map;for(let e of t||[]){let t=r.get(e.assumption_id)||{};"semantic"===e.embedding_kind&&(t.semanticEmbedding=s(e.embedding)),"concepts"===e.embedding_kind&&(t.conceptEmbedding=s(e.embedding)),r.set(e.assumption_id,t)}for(let e of o){let t=r.get(e.id);t&&l.push({assumptionId:e.id,semanticEmbedding:t.semanticEmbedding||null,conceptEmbedding:t.conceptEmbedding||null})}}let c=new Date(Date.now()-20736e6).toISOString(),{data:d,error:u}=await e.from("feedback_events").select("article_id,feedback_type,created_at").eq("user_id",t).in("feedback_type",["more_like_this","less_like_this","too_similar"]).not("article_id","is",null).gte("created_at",c).order("created_at",{ascending:!1}).limit(120);if(u)throw u;let m=Array.from(new Set((d||[]).map(e=>String(e.article_id)).filter(Boolean))),p=new Map;if(m.length){let{data:t,error:i}=await e.from("articles_for_ranking_view").select("id,embedding,concept_embedding").in("id",m);if(i)throw i;for(let e of t||[])p.set(String(e.id),{embedding:s(e.embedding),conceptEmbedding:s(e.concept_embedding)})}let h=[],g=new Set,f=new Set;for(let e of d||[]){var _;let t=String(e.article_id),i=String(e.feedback_type);if("too_similar"===i){if(f.has(t))continue;f.add(t)}else{if(g.has(t))continue;g.add(t)}let r=p.get(t);r&&(r.embedding?.length||r.conceptEmbedding?.length)&&h.push({articleId:t,kind:i,embedding:r.embedding,conceptEmbedding:r.conceptEmbedding,weight:(_=String(e.created_at),Math.exp(-Math.max(0,(Date.now()-new Date(_).getTime())/864e5)/("too_similar"===i?28:150)))})}return{preferenceEmbedding:n.get("preferences")||null,goalEmbedding:n.get("goals")||null,avoidanceEmbedding:n.get("avoidances")||null,goalVectors:l,articleFeedbackSignals:h}}async function c(e,t){let{data:i,error:a}=await e.from("user_profiles").select("*").eq("user_id",t).maybeSingle();if(a)throw a;let s=i?.reading_mode||"standard",{data:c,error:d}=await e.from("user_assumptions").select("*").eq("user_id",t).eq("active",!0);if(d)throw d;let u=c||[],{data:m}=await e.from("recommendation_items_view").select("article,created_at").eq("user_id",t).order("created_at",{ascending:!1}).limit(60),p=(m||[]).map(e=>e.article?.primary_iptc_qcode||e.article?.primary_topic).filter(Boolean),h=(m||[]).map(e=>e.article?.publisher_name).filter(Boolean),g=(m||[]).slice(0,30).map(e=>e.article?.id).filter(Boolean),f=e.from("articles_for_ranking_view").select("*").eq("status","active").gte("quality_score",.32).order("published_at",{ascending:!1,nullsFirst:!1}).limit(800);g.length&&(f=f.not("id","in",`(${g.join(",")})`));let{data:_,error:y}=await f;if(y)throw y;let b=await l(e,t,u),w=new Date(Date.now()-5184e6).toISOString(),{data:v,error:x}=await e.from("source_access_issues").select("source_id").eq("user_id",t).eq("status","open").gte("created_at",w);if(x)throw x;let S={};for(let e of v||[])e.source_id&&(S[e.source_id]=(S[e.source_id]||0)+1);let E=(0,r.Nl)({readingMode:s,articles:_||[],assumptions:u,recentTopics:p,recentPublishers:h,vectors:b,context:{noveltyTolerance:i?.novelty_tolerance||"medium",geographyPreferences:i?.geography_preferences||{},sourceExposure:i?.source_exposure||[],topicExclusions:i?.topic_exclusions||[],sourceAccessIssueCounts:S},explorationRate:.08}),A=E.selected.map(e=>e.article.id),k=new Map;if(A.length){let{data:t}=await e.from("articles").select("id,summary").in("id",A);for(let e of t||[])k.set(String(e.id),e.summary||null)}let I=await n(E.selected.map(e=>({article:e.article,slot:e.slot,features:e.features,reasonCodes:e.reasonCodes,fallback:e.explanation||"Chosen because it is a strong fit for your current reading profile.",summary:k.get(e.article.id)||null}))),N="light"===s?1:"deep"===s?5:3,{data:q,error:O}=await e.from("recommendation_runs").insert({user_id:t,model_version:o,reading_mode:s,status:"complete",requested_count:N,generated_count:E.selected.length,fallback_used:E.selected.length<N,user_state_snapshot:{reading_mode:i?.reading_mode||"standard",novelty_tolerance:i?.novelty_tolerance||"medium",geography_preferences:i?.geography_preferences||{},source_exposure:i?.source_exposure||[],topic_exclusions:i?.topic_exclusions||[],perspective_preferences:i?.perspective_preferences||{},explicit_preferences:(0,r.nz)(u,"preference").map(e=>({label:e.label,weight:e.weight,qcode:e.qcode,tag:e.tag})),goals:(0,r.nz)(u,"goal").map(e=>({label:e.label,weight:e.weight,qcode:e.qcode,tag:e.tag,concepts:Array.isArray(e.assumption.structured_value?.concepts)?e.assumption.structured_value.concepts:[],iptc_qcodes:Array.isArray(e.assumption.structured_value?.iptc_qcodes)?e.assumption.structured_value.iptc_qcodes:[]})),representation_mode:"precomputed_v1",exploration_rate:.08,generated_at:new Date().toISOString()}}).select("*").single();if(O)throw O;let P=E.candidates.map(e=>({recommendation_run_id:q.id,user_id:t,article_id:e.article.id,slot_type:e.slot,raw_score:e.rawScore,final_score:e.selected?e.finalScore:e.rawScore,eligible:e.eligible,rank_before_slate:e.rankBeforeSlate,selected:e.selected,exploration:e.exploration,selection_probability:e.selectionProbability,selection_policy:e.selectionPolicy,feature_snapshot:e.features,model_version:o})).filter(e=>e.selected||e.eligible&&e.rank_before_slate<=60||e.rank_before_slate<=20).slice(0,240);if(P.length){let{error:t}=await e.from("recommendation_candidates").insert(P);if(t)throw t}let D=E.selected.map((e,i)=>({recommendation_run_id:q.id,user_id:t,article_id:e.article.id,slot_type:e.slot,rank_position:i+1,score:e.finalScore,explanation_text:I.get(e.article.id)||e.explanation,explanation_reason_codes:e.reasonCodes,feature_snapshot:{...e.features,exploration:e.exploration,selectionProbability:e.selectionProbability,selectionPolicy:e.selectionPolicy},model_version:o}));if(D.length){let{error:t}=await e.from("recommendation_items").insert(D);if(t)throw t}return q}},9064:(e,t,i)=>{i.d(t,{R:()=>n});var r=i(9793),a=i(1964);function n(){return(0,r.eI)((0,a.O)("NEXT_PUBLIC_SUPABASE_URL"),(0,a.O)("SUPABASE_SERVICE_ROLE_KEY"),{auth:{autoRefreshToken:!1,persistSession:!1}})}}};