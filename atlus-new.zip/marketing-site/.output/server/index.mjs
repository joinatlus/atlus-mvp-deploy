globalThis.__nitro_main__ = import.meta.url;
import { H3Core, HTTPError, NodeResponse, composeMiddleware, createMatcherFromFind, defineHandler, defineLazyEventHandler, headers, memoizeRouteRulesMatcher, serve, toEventHandler } from "./_libs/h3+rou3+srvx.mjs";
import { HookableCore } from "./_libs/hookable.mjs";
import { decodePath, joinURL, withLeadingSlash, withoutTrailingSlash } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
// #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/apple-touch-icon.png": {
		"type": "image/png",
		"etag": "\"2530-ufT6u/3fKeIeo9WPV7oPY2WjvV4\"",
		"mtime": "2026-10-22T23:04:23.739Z",
		"size": 9520,
		"path": "../public/apple-touch-icon.png"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"443e-cejcJ1t0+LI2A6wBtqQ9q4xFQaA\"",
		"mtime": "2026-10-22T23:04:23.740Z",
		"size": 17470,
		"path": "../public/favicon.ico"
	},
	"/og-atlus.svg": {
		"type": "image/svg+xml",
		"etag": "\"3fe-0CXv5WVOtSzS0dg/43NQ7Jf6WPM\"",
		"mtime": "2026-10-22T23:04:23.741Z",
		"size": 1022,
		"path": "../public/og-atlus.svg"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"15d-8IsuM2jBNGtLndak0z64JohKppw\"",
		"mtime": "2026-10-22T23:04:23.739Z",
		"size": 349,
		"path": "../public/favicon.svg"
	},
	"/assets/faq-DVcAxpzY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3ae-xEv5b8LwpZqSIFAeX3u9RzPfWZU\"",
		"mtime": "2026-10-22T23:04:23.520Z",
		"size": 942,
		"path": "../public/assets/faq-DVcAxpzY.js"
	},
	"/assets/how-it-works-Bih2dLto.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1247-7pYZz0fXpxwiBNmskZroSIssPOA\"",
		"mtime": "2026-10-22T23:04:23.520Z",
		"size": 4679,
		"path": "../public/assets/how-it-works-Bih2dLto.js"
	},
	"/sitemap.xml": {
		"type": "application/xml",
		"etag": "\"22e-zRv5qR88C9s18xyL2490uTzpHeU\"",
		"mtime": "2026-10-22T23:04:23.742Z",
		"size": 558,
		"path": "../public/sitemap.xml"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"43-Ep2mZxsXLRKTDXQFY27C9+iXriA\"",
		"mtime": "2026-10-22T23:04:23.741Z",
		"size": 67,
		"path": "../public/robots.txt"
	},
	"/assets/manifesto-B1DOpHwm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"901-UqRirnkVvY5ihWwfI9u3KwEADz4\"",
		"mtime": "2026-10-22T23:04:23.520Z",
		"size": 2305,
		"path": "../public/assets/manifesto-B1DOpHwm.js"
	},
	"/assets/privacy-DhalG521.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b5c-H4s3qmpz2yleysXwyz+GCg0ZW/k\"",
		"mtime": "2026-10-22T23:04:23.520Z",
		"size": 2908,
		"path": "../public/assets/privacy-DhalG521.js"
	},
	"/assets/marks-C1bjHRZr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c8-8prir9xzA0t1bpjkh4sn5ghtwts\"",
		"mtime": "2026-10-22T23:04:23.520Z",
		"size": 1992,
		"path": "../public/assets/marks-C1bjHRZr.js"
	},
	"/assets/routes-CuCpEVLO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"644e-eVMsXVF2pPundfuqsu1w/0co8Ls\"",
		"mtime": "2026-10-22T23:04:23.520Z",
		"size": 25678,
		"path": "../public/assets/routes-CuCpEVLO.js"
	},
	"/assets/team-BTWRl0FR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a46-AMb/7WUiL4Bl1VIMoJTcIV6qhSM\"",
		"mtime": "2026-10-22T23:04:23.520Z",
		"size": 2630,
		"path": "../public/assets/team-BTWRl0FR.js"
	},
	"/assets/stated-preference-feed-CBRN_6xW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"46f9-7OZZf2KgH2A6+Zp76BizD08Sihc\"",
		"mtime": "2026-10-22T23:04:23.520Z",
		"size": 18169,
		"path": "../public/assets/stated-preference-feed-CBRN_6xW.js"
	},
	"/assets/styles-BfflqPoM.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"870d-ZtyjQKdtyFXxChmwgDEKwMIkW9o\"",
		"mtime": "2026-10-22T23:04:23.521Z",
		"size": 34573,
		"path": "../public/assets/styles-BfflqPoM.css"
	},
	"/images/cambridge-university-wordmark.jpeg": {
		"type": "image/jpeg",
		"etag": "\"6cf2-g9ReGCjw/2Dwv7WpUCNXv2P0Pqs\"",
		"mtime": "2026-10-22T23:04:23.736Z",
		"size": 27890,
		"path": "../public/images/cambridge-university-wordmark.jpeg"
	},
	"/assets/why-now-DCjhMe4c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3cf5-eqzLN+cqPYzPk5Jwjk/2k3L3SSk\"",
		"mtime": "2026-10-22T23:04:23.521Z",
		"size": 15605,
		"path": "../public/assets/why-now-DCjhMe4c.js"
	},
	"/images/cambridge-university-wordmark-teal.jpeg": {
		"type": "image/jpeg",
		"etag": "\"4bc5-/Br8qj6xjVTdwmleWge1i6CmYSc\"",
		"mtime": "2026-10-22T23:04:23.736Z",
		"size": 19397,
		"path": "../public/images/cambridge-university-wordmark-teal.jpeg"
	},
	"/images/durham-university-wordmark.png": {
		"type": "image/png",
		"etag": "\"3dab-P4wczMZ348NxoSSXiY/sP73ZIOo\"",
		"mtime": "2026-10-22T23:04:23.738Z",
		"size": 15787,
		"path": "../public/images/durham-university-wordmark.png"
	},
	"/images/cambridge-university.png": {
		"type": "image/png",
		"etag": "\"958f-ngBMs1sp+r64QjeUZ04LlRK7olo\"",
		"mtime": "2026-10-22T23:04:23.738Z",
		"size": 38287,
		"path": "../public/images/cambridge-university.png"
	},
	"/og-atlus.png": {
		"type": "image/png",
		"etag": "\"59061-yiQY/bxAKHGsBf2493tq+7dpy0s\"",
		"mtime": "2026-10-22T23:04:23.749Z",
		"size": 364641,
		"path": "../public/og-atlus.png"
	},
	"/images/durham-university.png": {
		"type": "image/png",
		"etag": "\"82fb-Uvhx5agHmQYHUq5D3B/bBuAHsMs\"",
		"mtime": "2026-10-22T23:04:23.737Z",
		"size": 33531,
		"path": "../public/images/durham-university.png"
	},
	"/assets/index-ByVlbnuw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6a827-ZKHFV4PezJVOf6gtgYvHFeasZHo\"",
		"mtime": "2026-10-22T23:04:23.519Z",
		"size": 436263,
		"path": "../public/assets/index-ByVlbnuw.js"
	},
	"/images/founders.jpg": {
		"type": "image/jpeg",
		"etag": "\"5fb88-89RluTBu4yV1S3g+AP/q3iVZfHc\"",
		"mtime": "2026-10-22T23:04:23.743Z",
		"size": 392072,
		"path": "../public/images/founders.jpg"
	},
	"/images/josephine-butler-college-crest-transparent.png": {
		"type": "image/png",
		"etag": "\"a5224-Wy7S5uNU2LQOCIHXalhKQmfxGYQ\"",
		"mtime": "2026-10-22T23:04:23.752Z",
		"size": 676388,
		"path": "../public/images/josephine-butler-college-crest-transparent.png"
	},
	"/images/josephine-butler-college-crest.jpeg": {
		"type": "image/jpeg",
		"etag": "\"5868-KI5za9oa1RN77Hq3JQh1/p/PKZQ\"",
		"mtime": "2026-10-22T23:04:23.737Z",
		"size": 22632,
		"path": "../public/images/josephine-butler-college-crest.jpeg"
	}
};
// #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
// #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
// node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
// #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = {
		route: "/assets/**",
		rank: 0,
		rules: [{
			name: "headers",
			route: "/assets/**",
			handler: headers,
			options: { "cache-control": "public, max-age=31536000, immutable" }
		}]
	};
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1);
		let s = p.split("/");
		let l = s.length;
		let _w;
		if (l > 1) {
			if (s[1] === "assets") r.push(l > 2 ? {
				data: $0,
				params: {
					"0": _w = p.slice(8),
					_: _w
				}
			} : {
				data: $0,
				params: {}
			});
		}
		return r.reverse();
	};
})();
var _lazy_17963170a46cdab2 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_17963170a46cdab2
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
// node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
// #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
// #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => {
		event.context.routeRules = getRouteRules(event.req.method, event.url.pathname).routeRules;
		return findRoute(event.req.method, event.url.pathname);
	};
	h3App["~middleware"].push(createRouteRulesMiddleware());
	h3App["~middleware"].push(...globalMiddleware);
	return h3App;
}
// node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
var _matchRouteRules;
function getRouteRules(method, pathname) {
	return (_matchRouteRules ??= memoizeRouteRulesMatcher(createMatcherFromFind(findRouteRules)))(method, pathname);
}
function createRouteRulesMiddleware() {
	const composed = /* @__PURE__ */ new WeakMap();
	const middleware = (event, next) => {
		const ruleMiddleware = getRouteRules(event.req.method, event.url.pathname).routeRuleMiddleware;
		if (ruleMiddleware.length === 0) return next();
		let chain = composed.get(ruleMiddleware);
		if (!chain) {
			chain = composeMiddleware(ruleMiddleware);
			composed.set(ruleMiddleware, chain);
		}
		return chain(event, next);
	};
	return markUntraced(middleware);
}
function markUntraced(middleware) {
	middleware.__traced__ = true;
	return middleware;
}
// node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
// #nitro/virtual/tracing
var tracingSrvxPlugins = [];
// node_modules/nitro/dist/runtime/internal/shutdown.mjs
function setupCloseHooks(server) {
	const closeServer = server.close.bind(server);
	let closeHooks;
	server.close = (closeActiveConnections) => closeServer(closeActiveConnections).finally(() => closeHooks ??= callCloseHooks());
}
async function callCloseHooks() {
	try {
		await useNitroHooks().callHook("close");
	} catch (error) {
		console.error("[nitro] Error while calling `close` hooks:", error);
	}
}
// node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
setupCloseHooks(serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
}));
trapUnhandledErrors();
var node_server_default = {};
export { node_server_default as default };
