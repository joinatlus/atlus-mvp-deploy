// node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BA1HQpyS.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Users/henry/Downloads/atlus-mvp-free-deploy-clean/marketing-site/src/routes/__root.tsx",
		children: [
			"/",
			"/faq",
			"/how-it-works",
			"/manifesto",
			"/privacy",
			"/team",
			"/why-now",
			"/science/stated-preference-feed"
		],
		preloads: ["/assets/index-ByVlbnuw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ByVlbnuw.js"
		} }]
	},
	"/": {
		filePath: "/Users/henry/Downloads/atlus-mvp-free-deploy-clean/marketing-site/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CuCpEVLO.js", "/assets/marks-C1bjHRZr.js"]
	},
	"/faq": {
		filePath: "/Users/henry/Downloads/atlus-mvp-free-deploy-clean/marketing-site/src/routes/faq.tsx",
		children: void 0,
		preloads: ["/assets/faq-DVcAxpzY.js"]
	},
	"/how-it-works": {
		filePath: "/Users/henry/Downloads/atlus-mvp-free-deploy-clean/marketing-site/src/routes/how-it-works.tsx",
		children: void 0,
		preloads: ["/assets/how-it-works-Bih2dLto.js"]
	},
	"/manifesto": {
		filePath: "/Users/henry/Downloads/atlus-mvp-free-deploy-clean/marketing-site/src/routes/manifesto.tsx",
		children: void 0,
		preloads: ["/assets/manifesto-B1DOpHwm.js", "/assets/marks-C1bjHRZr.js"]
	},
	"/privacy": {
		filePath: "/Users/henry/Downloads/atlus-mvp-free-deploy-clean/marketing-site/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-DhalG521.js"]
	},
	"/team": {
		filePath: "/Users/henry/Downloads/atlus-mvp-free-deploy-clean/marketing-site/src/routes/team.tsx",
		children: void 0,
		preloads: ["/assets/team-BTWRl0FR.js"]
	},
	"/why-now": {
		filePath: "/Users/henry/Downloads/atlus-mvp-free-deploy-clean/marketing-site/src/routes/why-now.tsx",
		children: void 0,
		preloads: ["/assets/why-now-DCjhMe4c.js"]
	},
	"/science/stated-preference-feed": {
		filePath: "/Users/henry/Downloads/atlus-mvp-free-deploy-clean/marketing-site/src/routes/science/stated-preference-feed.tsx",
		children: void 0,
		preloads: ["/assets/stated-preference-feed-CBRN_6xW.js"]
	}
} });
export { tsrStartManifest };
