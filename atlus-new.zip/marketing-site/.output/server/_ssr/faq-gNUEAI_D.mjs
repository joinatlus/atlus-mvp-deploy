import { require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { Page, questions } from "./router-BzoSQJH-.mjs";
// node_modules/.nitro/vite/services/ssr/assets/faq-gNUEAI_D.js
var import_jsx_runtime = require_jsx_runtime();
function FaqPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		headerVariant: "light",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "mx-auto max-w-3xl px-6 pb-24 pt-40 sm:px-10",
			style: { fontFamily: "var(--font-serif)" },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-5 text-sm tracking-[0.25em]",
					style: { color: "var(--color-amber)" },
					children: "FAQ"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mb-10 text-[clamp(2.5rem,6vw,4.5rem)] leading-[1.02] tracking-tight",
					style: {
						fontFamily: "var(--font-display)",
						fontWeight: 800
					},
					children: "A few useful answers."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y",
					style: { borderColor: "rgba(13,27,42,0.14)" },
					children: questions.map(({ question, answer }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "py-7",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 700
							},
							children: question
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-lg leading-relaxed opacity-85",
							children: answer
						})]
					}, question))
				})
			]
		})
	});
}
export { FaqPage as component };
