import { require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { Page } from "./router-BzoSQJH-.mjs";
// node_modules/.nitro/vite/services/ssr/assets/privacy-DDWz9DNx.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		headerVariant: "light",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "mx-auto max-w-3xl px-6 pb-24 pt-40 sm:px-10",
			style: { fontFamily: "var(--font-serif)" },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-5 text-sm tracking-[0.25em]",
					style: { color: "var(--color-amber)" },
					children: "PRIVACY"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mb-8 text-[clamp(2.5rem,6vw,4.5rem)] leading-[1.02] tracking-tight",
					style: {
						fontFamily: "var(--font-display)",
						fontWeight: 800
					},
					children: "Personalisation should remain personal."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-6 text-lg leading-relaxed",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Atlus is designed around information readers choose to share. That information helps us create more useful recommendations; it is not a product to be sold." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-3 text-3xl",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 700
							},
							children: "What it is for"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Atlus keeps your email, the answers you choose to give during onboarding, your delivery settings and exclusions, the recommendation profile built from those answers, the articles you open, and the feedback you give. This information is used to select your daily edition, explain why each story is there, and improve future recommendations." })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-3 text-3xl",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 700
							},
							children: "How it learns"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Your explicit choices are the foundation: interests, goals, existing knowledge and anything you want Atlus to avoid. As you use it, article opens and feedback such as More like this, Less like this, Too basic, or Go further refine that profile. Atlus uses the same broad family of recommendation methods as large social platforms, but with a different objective: usefulness to you, rather than keeping you on a feed." })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-3 text-3xl",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 700
							},
							children: "Your control"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"The information used to choose your articles is available in your profile in plain language. You can correct an assumption, change an exclusion or delivery setting, and delete your account and its data at any time. Until you delete it, the information is kept so Atlus can maintain and improve your daily edition. You can contact us at",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "underline",
								href: "mailto:sam@joinatlus.com",
								children: "sam@joinatlus.com"
							}),
							" ",
							"with privacy questions."
						] })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "border-l-4 pl-5 text-base opacity-75",
							style: { borderColor: "var(--color-amber)" },
							children: "This plain-English page describes the product principle. It should be reviewed alongside the final legal privacy notice before public launch."
						})
					]
				})
			]
		})
	});
}
export { PrivacyPage as component };
