import { __toESM } from "./rolldown-runtime-DDijeYup.mjs";
import { require_jsx_runtime, require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { Page, faqs } from "./router-BzoSQJH-.mjs";
// node_modules/.nitro/vite/services/ssr/assets/stated-preference-feed-D4iwhNbh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var sources = [
	["Milli, S., Carroll, M., Wang, Y., Pandey, S., Zhao, S. & Dragan, A. D. (2025). Engagement, user satisfaction, and the amplification of divisive content on social media. PNAS Nexus, 4(3), pgaf062.", "https://doi.org/10.1093/pnasnexus/pgaf062"],
	["Milli, S. et al. (2024). Engagement, User Satisfaction, and the Amplification of Divisive Content on Social Media. Knight First Amendment Institute.", "https://knightcolumbia.org/content/engagement-user-satisfaction-and-the-amplification-of-divisive-content-on-social-media"],
	["Kleinberg, J., Mullainathan, S. & Raghavan, M. (2024). The challenge of understanding what users want: Inconsistent preferences and engagement optimization. Management Science, 70(9), 6336–6355.", "https://doi.org/10.1287/mnsc.2022.03683"],
	["Khambatta, P., Mariadassou, S., Morris, J. & Wheeler, S. C. (2023). Tailoring recommendation algorithms to ideal preferences makes users better off. Scientific Reports, 13, 9325.", "https://doi.org/10.1038/s41598-023-34192-x"],
	["Kim, D. W., Buntain, C. & Ciampaglia, G. L. (2026). Understanding the Gap Between Stated and Revealed Preferences in News Curation: A Study of Young Adult Social Media Users. arXiv:2604.11517 (preprint).", "https://arxiv.org/abs/2604.11517"],
	["Cunningham, T. et al. (2024). What We Know About Using Non-Engagement Signals in Content Ranking. arXiv:2402.06831 (preprint).", "https://arxiv.org/abs/2402.06831"],
	["Reuters Institute for the Study of Journalism (2025). Digital News Report 2025.", "https://reutersinstitute.politics.ox.ac.uk/digital-news-report/2025/dnr-executive-summary"],
	["Reuters Institute for the Study of Journalism (2026). Digital News Report 2026.", "https://reutersinstitute.politics.ox.ac.uk/digital-news-report/2026/dnr-executive-summary"],
	["Press Gazette (2026). News publishing trends for 2026.", "https://pressgazette.co.uk/publishers/digital-journalism/news-publishing-trends-for-2026/"],
	["Milli, S., Belli, L. & Hardt, M. (2021). From Optimizing Engagement to Measuring Value. Proceedings of the 2021 ACM Conference on Fairness, Accountability, and Transparency, 714–722.", "https://doi.org/10.1145/3442188.3445933"]
];
var sourceNumbers = {
	S1: 1,
	S1b: 2,
	S2: 3,
	S3: 4,
	S4: 5,
	S5b: 6,
	S5: 7,
	S6: 8,
	S7: 9,
	S8: 10
};
function Cite({ ids }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("sup", {
		className: "ml-1 whitespace-nowrap text-xs font-semibold leading-none",
		children: ids.map((id, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [index > 0 && ",", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			className: "underline decoration-1 underline-offset-2 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2",
			href: `#source-${sourceNumbers[id]}`,
			"aria-label": `Source ${sourceNumbers[id]}`,
			children: sourceNumbers[id]
		})] }, id))
	});
}
function StatedPreferenceFeedPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		headerVariant: "light",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "mx-auto max-w-4xl px-6 pb-24 pt-40 sm:px-10",
			style: { fontFamily: "var(--font-serif)" },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "max-w-3xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-5 text-sm tracking-[0.25em]",
							style: { color: "var(--color-amber)" },
							children: "THE SCIENCE OF ATLUS"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-[clamp(2.8rem,7vw,5.4rem)] leading-[0.98] tracking-tight",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 800
							},
							children: "A feed built on what you want, not what you click"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-9 text-[clamp(1.45rem,3vw,2rem)] leading-snug",
							style: { fontFamily: "var(--font-display)" },
							children: [
								"A ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "stated-preference feed" }),
								" ranks content by what readers tell it they want to read and learn, rather than by predicting what they will click, like or share."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 text-xl leading-relaxed opacity-80",
							children: ["Most feeds learn from your behaviour in the moment. Research shows that behaviour often isn't what you'd choose on reflection. Atlus is built on the difference.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1", "S2"] })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					id: "problem",
					title: "Why your feed doesn't give you what you want",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Most social and news feeds optimise for your ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "revealed preferences" }),
							": the clicks, shares and likes you produce.",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1"] }),
							" The logic is simple. Watch what people do, then show them more of it."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["The trouble is that what we do in the moment often doesn't match what we actually want.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S2"] })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Computer scientists Jon Kleinberg, Sendhil Mullainathan and Manish Raghavan explain it with a party. You empty the bowl of crisps on the table. Your host sees this, decides you want more, and refills it. You empty it again. You leave feeling you ate far too many. The host assumed your behaviour revealed your preference. It didn't.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S2"] })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-2xl italic",
							style: { fontFamily: "var(--font-display)" },
							children: "An engagement-optimised feed is that host. It keeps refilling the bowl."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					id: "evidence",
					title: "What the research shows",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Evidence, {
							title: "Engagement ranking amplifies anger that users don't want",
							citations: ["S1", "S1b"],
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["In a preregistered audit, researchers from Berkeley and Cornell compared Twitter's engagement-ranked timeline with a simple reverse-chronological one.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1"] })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["The engagement algorithm amplified emotionally charged, hostile content that made users feel worse about people on the other side of politics.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1"] })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Among political posts, 62% of those picked by the algorithm expressed anger, against 52% in the chronological feed.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1b"] })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									"Users did ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "not" }),
									" prefer the political posts the algorithm chose.",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1"] })
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									"When the researchers re-ranked the same posts by what users ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "said" }),
									" they wanted, angry, partisan and hostile content fell.",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1"] })
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "mt-5 list-none text-sm opacity-70",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "Study: Milli et al., PNAS Nexus (2025). 806 US Twitter users, February 2023." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1", "S1b"] })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Evidence, {
							title: "Ranking for your ideals makes you feel better off",
							citations: ["S3"],
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									"Researchers at UCLA and Stanford built recommendation systems tuned to either people's",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "actual" }),
									" preferences or their ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "ideal" }),
									" preferences, then tested them in a preregistered experiment with 6,488 participants.",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S3"] })
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Targeting ideal preferences produced somewhat fewer clicks, but people felt better off and felt their time was better spent.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S3"] })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["They were also more willing to pay for the service, more likely to use it again, and more likely to feel the company had their best interests at heart.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S3"] })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "mt-5 list-none text-sm opacity-70",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "Study: Khambatta et al., Scientific Reports (2023)." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S3"] })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Evidence, {
							title: "Young adults want better news than their feeds give them",
							citations: ["S4"],
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["A 2026 University of Maryland study of 18–24-year-olds found participants often engaged with low-quality content they didn't endorse, despite wanting high-quality information.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S4"] })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["When asked to design an ideal news feed, they prioritised values such as accuracy and diversity, and rated the result as more satisfying and higher quality.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S4"] })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Sixteen of 20 participants put balance first when designing their ideal feed, while only five prioritised entertainment. The stated-preference feed differed from the engagement feed more than a random feed did, without reducing viewpoint diversity.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S4"] })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "mt-5 list-none text-sm opacity-70",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "Study: Kim, Buntain and Ciampaglia, arXiv preprint (2026), not yet peer reviewed." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S4"] })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-8 text-base leading-relaxed opacity-75",
							children: [
								"This matters because people are switching off. 42% of people across 48 markets now sometimes or often avoid the news, up from 29% in 2017.",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S6"] }),
								" In the UK the figure is 50%.",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S7"] }),
								" The most common reasons given are the news worsening their mood and feeling worn out by the sheer volume.",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S5"] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 rounded-2xl p-6 text-2xl leading-snug",
							style: {
								background: "var(--color-royal)",
								color: "var(--color-platinum)",
								fontFamily: "var(--font-display)"
							},
							children: "Together, the evidence suggests that what people click and what people want are different things. Atlus builds for what they want."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					id: "comparison",
					title: "Revealed preference vs stated preference",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto rounded-2xl border",
						style: { borderColor: "rgba(13,27,42,0.16)" },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "min-w-[820px] w-full border-collapse text-left text-base leading-relaxed",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("caption", {
									className: "sr-only",
									children: "Comparison of engagement and stated-preference feeds"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									style: { background: "rgba(13,27,42,0.06)" },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "p-5",
											scope: "col"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("th", {
											className: "p-5",
											scope: "col",
											children: [
												"Engagement feed",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-normal opacity-70",
													children: "Revealed preference"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "p-5",
											scope: "col",
											children: "Stated-preference feed"
										})
									] })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComparisonRow, {
										label: "Learns from",
										left: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Clicks, likes, shares, dwell time", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1"] })] }),
										right: "What you tell it you want to read and learn"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComparisonRow, {
										label: "Optimises for",
										left: "Keeping you engaged",
										right: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Content you'd endorse on reflection", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1", "S3"] })] })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComparisonRow, {
										label: "Mental model",
										left: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["The host who keeps refilling the bowl", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S2"] })] }),
										right: "Asking you what you'd actually like"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComparisonRow, {
										label: "Known risk",
										left: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Amplifies anger and hostility", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1"] })] }),
										right: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Can narrow you towards views you already hold", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1"] })] })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComparisonRow, {
										label: "Atlus's answer to the risk",
										left: "n/a",
										right: "Stretch and Discovery picks outside your usual diet"
									})
								] })
							]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					id: "atlus-in-practice",
					title: "How Atlus puts it into practice",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-5 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Feature, {
								title: "You tell us, up front.",
								children: [
									"Onboarding asks three things: what you enjoy reading (",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Preferences" }),
									"), what you want to understand better (",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Goals" }),
									"), and what you already know (",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Knowledge" }),
									"), so we don't repeat it."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
								title: "A few picks, then done.",
								children: "Choose Light (1 article), Standard (3) or Deep (5) each day. No infinite scroll."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Feature, {
								title: "Deliberate breadth.",
								children: [
									"Every day mixes ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Core" }),
									" picks close to your interests,",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Stretch" }),
									" picks that serve your goals, and ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Discovery" }),
									" ",
									"picks from outside your usual media diet."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
								title: "You can see why.",
								children: "Every article says why it was chosen, and you can view and edit what Atlus assumes about you."
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					id: "limits",
					title: "What the research doesn't say",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We'd rather be precise than oversell." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-6 space-y-5 pl-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Stated preferences can narrow your view." }),
								" In the Twitter study, ranking by stated preference cut hostile content, but it did so partly by showing fewer posts from people's political opponents.",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1", "S1b"] }),
								" This is why Atlus builds Stretch and Discovery picks into every day."
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "The Twitter experiment was small in scope." }),
								" The stated-preference ranking re-ordered only about 20 posts per user, so results at full platform scale are untested.",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1b"] })
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Researchers don't say engagement data is useless." }),
								" The authors of the Twitter study explicitly do not advocate abandoning it. They suggest combining it with what users say they want.",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S1b", "S8"] })
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Explaining recommendations isn't proven to keep users." }),
								" An industry-academic review found no strong evidence that transparency or explanations improve retention.",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S5b"] }),
								" We explain our picks because you deserve to know, not because it's a growth trick."
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "One study is a preprint." }),
								" The University of Maryland study has not yet been peer reviewed.",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: ["S4"] })
							] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					id: "faq",
					title: "Frequently asked questions",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Faq, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sources, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "join",
					className: "mt-20 rounded-3xl px-7 py-12 text-center sm:px-12",
					style: {
						background: "var(--color-royal)",
						color: "var(--color-platinum)"
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-4xl",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 700
							},
							children: "Read with more intention."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto mt-4 max-w-xl text-lg leading-relaxed opacity-80",
							children: "A small daily paper, chosen with you in mind."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/#join",
							className: "mt-7 inline-flex rounded-full px-6 py-3 text-sm font-semibold tracking-wide transition-transform hover:-translate-y-0.5 motion-reduce:transition-none motion-reduce:hover:translate-y-0 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4",
							style: {
								background: "var(--color-amber)",
								color: "var(--color-royal)"
							},
							children: "Start onboarding"
						})
					]
				})
			]
		})
	});
}
function Section({ id, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id,
		className: "mt-24 scroll-mt-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-8 text-[clamp(2rem,4vw,3.2rem)] leading-tight",
			style: {
				fontFamily: "var(--font-display)",
				fontWeight: 700
			},
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-6 text-lg leading-relaxed",
			children
		})]
	});
}
function Evidence({ title, citations, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border p-6 sm:p-8",
		style: {
			borderColor: "rgba(13,27,42,0.16)",
			background: "white"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
			className: "text-2xl leading-tight",
			style: {
				fontFamily: "var(--font-display)",
				fontWeight: 700
			},
			children: [title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: citations })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-5 space-y-4 pl-5",
			children
		})]
	});
}
function ComparisonRow({ label, left, right }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-t",
		style: { borderColor: "rgba(13,27,42,0.12)" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "p-5 align-top",
				scope: "row",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "p-5 align-top",
				children: left
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "p-5 align-top",
				children: right
			})
		]
	});
}
function Feature({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border p-6",
		style: {
			borderColor: "rgba(13,27,42,0.16)",
			background: "white"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-2xl",
			style: {
				fontFamily: "var(--font-display)",
				fontWeight: 700
			},
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 leading-relaxed opacity-85",
			children
		})]
	});
}
function Faq() {
	const [openIndex, setOpenIndex] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "divide-y rounded-2xl border",
		style: {
			borderColor: "rgba(13,27,42,0.16)",
			background: "white"
		},
		children: faqs.map(({ question, answer, citations }, index) => {
			const isOpen = openIndex === index;
			const contentId = `faq-answer-${index}`;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-full items-center justify-between gap-6 py-6 text-left text-xl focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4",
					"aria-expanded": isOpen,
					"aria-controls": contentId,
					onClick: () => setOpenIndex(isOpen ? null : index),
					style: {
						fontFamily: "var(--font-display)",
						fontWeight: 700
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: question }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						className: "text-2xl",
						children: isOpen ? "−" : "+"
					})]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					id: contentId,
					hidden: !isOpen,
					className: "pb-6 text-lg leading-relaxed",
					children: [answer, citations.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cite, { ids: citations })]
				})]
			}, question);
		})
	});
}
function Sources() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "sources",
		className: "mt-24 scroll-mt-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-8 text-[clamp(2rem,4vw,3.2rem)]",
				style: {
					fontFamily: "var(--font-display)",
					fontWeight: 700
				},
				children: "Sources"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "space-y-5 text-sm leading-relaxed opacity-80",
				children: sources.map(([reference, url], index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					id: `source-${index + 1}`,
					className: "scroll-mt-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mr-2 font-semibold",
						children: [index + 1, "."]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "underline decoration-1 underline-offset-2 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2",
						href: url,
						target: "_blank",
						rel: "noopener",
						children: reference
					})]
				}, url))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-12 text-2xl",
				style: {
					fontFamily: "var(--font-display)",
					fontWeight: 700
				},
				children: "Further reading"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-4 list-disc space-y-3 pl-6 text-sm leading-relaxed opacity-80",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Stray, J. et al. (2022). Building Human Values into Recommender Systems: An Interdisciplinary Synthesis. arXiv:2207.10192." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Ekstrand, M. D. & Willemsen, M. C. (2016). Behaviorism is Not Enough: Better Recommendations through Listening to Users. RecSys '16, 221–224." })]
			})
		]
	});
}
export { StatedPreferenceFeedPage as component };
