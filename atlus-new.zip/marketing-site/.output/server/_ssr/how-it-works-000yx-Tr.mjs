import { require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { Page } from "./router-BzoSQJH-.mjs";
// node_modules/.nitro/vite/services/ssr/assets/how-it-works-000yx-Tr.js
var import_jsx_runtime = require_jsx_runtime();
function HowItWorksPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		headerVariant: "light",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "mx-auto max-w-3xl px-6 pb-24 pt-40 sm:px-10",
			style: { fontFamily: "var(--font-serif)" },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-5 text-sm tracking-[0.25em]",
					style: { color: "var(--color-amber)" },
					children: "HOW IT WORKS"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mb-8 text-[clamp(2.5rem,6vw,4.5rem)] leading-[1.02] tracking-tight",
					style: {
						fontFamily: "var(--font-display)",
						fontWeight: 800
					},
					children: "A daily paper built around what matters to you."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xl leading-relaxed",
					children: "Atlus is a personalised daily edition delivered by email once a day, at the time you choose. You tell us what interests you and what you want to understand; we use that context to select three full-length articles for you."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-14",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 700
							},
							children: "From onboarding to your inbox"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid gap-5 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoryType, {
									name: "Tell us",
									text: "Share your interests, learning goals, existing knowledge, exclusions, and sources you already read."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoryType, {
									name: "Check us",
									text: "Review the profile Atlus assembles and correct anything it has misunderstood."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoryType, {
									name: "Choose when",
									text: "Set your delivery time. We recommend about 30 minutes after you wake up."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-lg leading-relaxed",
							children: "Create an account, complete onboarding, and see your first recommendations on Today. Choose when your daily email arrives."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-14",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-3xl",
						style: {
							fontFamily: "var(--font-display)",
							fontWeight: 700
						},
						children: "Three ways into the news"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid gap-5 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoryType, {
								name: "Core",
								text: "Stories connected to the subjects you already care about."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoryType, {
								name: "Stretch",
								text: "Stories that move you closer to something you want to understand."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoryType, {
								name: "Discovery",
								text: "Stories from beyond your usual orbit, chosen to widen the view."
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-14 space-y-5 text-lg leading-relaxed",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 700
							},
							children: "Personalisation with a reason"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Atlus is designed to make its recommendations legible. A story should have a reason for appearing in your paper: something you follow, something you are trying to learn, or a useful connection you might otherwise miss." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Onboarding creates the first version of your profile. The articles you open and feedback such as More like this, Less like this, Too basic, or Go further refine it over time. The assumptions behind those choices remain visible and editable." })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-14 space-y-5 text-lg leading-relaxed",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 700
							},
							children: "Original reporting, chosen more widely"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Atlus links you to each publisher's full article rather than replacing it with an AI summary. Access to the original article depends on the publisher; if a link is blocked for you, let us know so we can improve future picks." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Founder Sam Oliver curates the source list. It combines established publishers with specialist newsletters, independent Substacks, small outlets and international sources that rarely enter a typical Western media diet, including",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "https://kuwaittimes.com/",
								target: "_blank",
								rel: "noopener",
								className: "underline decoration-1 underline-offset-4",
								children: "Kuwait Times"
							}),
							"."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Every outlet is reviewed before inclusion. Alongside a recommendation, we aim to show its broad political perspective and where that assessment came from. A label is a clue about viewpoint, not a guarantee that an individual article is unbiased or accurate; the goal is to help you read with context and encounter more than one perspective." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Atlus is free to use." })
					]
				})
			]
		})
	});
}
function StoryType({ name, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border p-5",
		style: {
			borderColor: "rgba(13,27,42,0.14)",
			background: "white"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-2xl",
			style: {
				fontFamily: "var(--font-display)",
				fontWeight: 700
			},
			children: name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 leading-relaxed opacity-80",
			children: text
		})]
	});
}
export { HowItWorksPage as component };
