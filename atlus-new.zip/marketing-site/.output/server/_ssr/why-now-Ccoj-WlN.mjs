import { Link, require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { Page } from "./router-BzoSQJH-.mjs";
// node_modules/.nitro/vite/services/ssr/assets/why-now-Ccoj-WlN.js
var import_jsx_runtime = require_jsx_runtime();
var audienceStats = [
	["37%", "Global trust in news, the lowest since tracking began in 2015."],
	["42%", "Sometimes or often avoid the news, up from 29% in 2017."],
	["54%", "Use social and video networks for news, ahead of news sites and apps (51%)."],
	["52%", "Of 18–24s say social, video or AI is their main source of news."]
];
var attentionProducts = [
	["Opal", "1M+ daily active users and $10M+ ARR; claims 500M hours of screen time saved."],
	["one sec", "A PNAS study found app openings fell 57% over six weeks (n = 280)."],
	["Bloom", "60,000+ physical blockers sold."],
	["Brick", "A $59 physical blocker with strong growth among 20–35 year olds."]
];
var policyTimeline = [
	[
		"Dec 2025",
		"Australia",
		"Under-16 social-media ban takes effect; penalties can reach AUD 49.5M."
	],
	[
		"Jan 2026",
		"France",
		"Lawmakers pass a bill to ban social media for under-15s."
	],
	[
		"Feb 2026",
		"European Union",
		"The Commission preliminarily finds TikTok's addictive design may breach the Digital Services Act."
	],
	[
		"Feb 2026",
		"Spain",
		"Government announces an under-16 social-media plan."
	],
	[
		"Feb 2026",
		"Portugal",
		"Parental consent required for 13–16s, with fines tied to global revenue."
	],
	[
		"Mar 2026",
		"Indonesia",
		"Under-16 restrictions announced for high-risk platforms."
	],
	[
		"Mar 2026",
		"United States",
		"Los Angeles jury finds Meta and YouTube negligent in a social-media addiction trial."
	],
	[
		"Jun–Jul 2026",
		"United Kingdom",
		"Under-16 restrictions, a night-time curfew, and infinite scroll and autoplay proposals move forward."
	],
	[
		"2025–26",
		"Across the world",
		"Denmark, Norway, Greece, Poland, Slovenia, Malaysia and Canada advance age-limit proposals."
	]
];
function WhyNowPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		headerVariant: "light",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "mx-auto max-w-5xl px-6 pb-24 pt-40 sm:px-10",
			style: {
				fontFamily: "var(--font-serif)",
				color: "var(--color-royal)"
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "max-w-4xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-5 text-sm tracking-[0.25em]",
							style: { color: "var(--color-amber)" },
							children: "WHY NOW"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-[clamp(2.8rem,7vw,5.6rem)] leading-[0.98] tracking-tight",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 800
							},
							children: "The problem isn't the news. It's the feed."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 max-w-3xl text-[clamp(1.35rem,3vw,2rem)] leading-snug",
							style: { fontFamily: "var(--font-display)" },
							children: "Audiences are turning away from engagement feeds, people are paying to use their phones less, and governments are moving from warnings to enforcement. Atlus is built for that moment."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-12 rounded-3xl p-7 sm:p-12",
					style: {
						background: "var(--color-royal)",
						color: "var(--color-platinum)"
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-7 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[clamp(4.5rem,10vw,7rem)] leading-none",
								style: {
									fontFamily: "var(--font-display)",
									fontWeight: 800
								},
								children: "42%"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-lg leading-snug opacity-80",
								children: "of people sometimes or often avoid the news."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[clamp(4.5rem,10vw,7rem)] leading-none",
								style: {
									fontFamily: "var(--font-display)",
									fontWeight: 800
								},
								children: "37%"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-lg leading-snug opacity-80",
								children: "global trust in news, the lowest since tracking began in 2015."
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-9 max-w-3xl text-xl leading-relaxed",
							style: { fontFamily: "var(--font-display)" },
							children: "The audience has not stopped wanting news. It has stopped trusting the way news reaches it."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
							href: "https://reutersinstitute.politics.ox.ac.uk/digital-news-report/2026/dnr-executive-summary",
							dark: true,
							children: "Reuters Institute Digital News Report 2026"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ContentSection, {
					id: "audiences",
					title: "Audiences are leaving the feed",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The feed has become the default route to news: convenient, ambient, and designed around engagement. The result is a growing gap between being exposed to news and feeling informed by it." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid gap-4 sm:grid-cols-2",
							children: audienceStats.map(([stat, meaning]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
								stat,
								meaning
							}, stat))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 grid gap-5 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									title: "Trust has collapsed",
									children: "Trust fell significantly in 29 of 48 markets. Only 22% trust news found on social media and 20% trust it from AI chatbots; 62% are concerned about what is real online."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									title: "People are switching off",
									children: "The share who are very or extremely interested in news has fallen 13 points since 2021. Casual, low-interest news users have grown from 16% to 25%."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									title: "News is increasingly incidental",
									children: "Most Facebook, Instagram and TikTok users encounter news while doing something else. For many younger readers, it is no longer a deliberate habit."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									title: "Demand for better news remains",
									children: "45% prefer news that does not take sides, and values-led reasons remain a major reason people pay for journalism."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-sm opacity-70",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
								href: "https://reutersinstitute.politics.ox.ac.uk/digital-news-report/2026/dnr-executive-summary",
								children: "Source: Reuters Institute Digital News Report 2026"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ContentSection, {
					id: "attention",
					title: "People are paying to scroll less",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Screen-time and blocker tools have gone mainstream. They show that people will pay to take back control of their attention. Atlus is the news-shaped version of that movement." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 overflow-x-auto rounded-2xl border",
							style: { borderColor: "rgba(13,27,42,0.16)" },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "min-w-[620px] w-full border-collapse text-left",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("caption", {
										className: "sr-only",
										children: "Evidence that people pay to reduce screen time"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										style: { background: "rgba(13,27,42,0.06)" },
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "p-5",
											scope: "col",
											children: "Product"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "p-5",
											scope: "col",
											children: "Proof point"
										})] })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: attentionProducts.map(([product, proof]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t",
										style: { borderColor: "rgba(13,27,42,0.12)" },
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "p-5 align-top",
											scope: "row",
											children: product
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-5 align-top",
											children: proof
										})]
									}, product)) })
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 grid gap-4 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
								title: "Blockers subtract",
								children: "They take the feed away, often successfully."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
								title: "Atlus adds back what is worth keeping",
								children: "A finite daily edition, stated preferences, a reason for every recommendation, and a link back to the original publisher."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 text-sm opacity-70",
							children: [
								"Sources:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
									href: "https://www.pnas.org/doi/10.1073/pnas.2213114120",
									children: "one sec PNAS study"
								}),
								",",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
									href: "https://www.revenuecat.com/blog/growth/kenneth-schlenker-sub-club-podcast-2026",
									children: "RevenueCat on Opal"
								}),
								", and",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
									href: "https://fortune.com/2026/02/13/analog-gen-z-phone-addiction-bloom-brick-app-blockers-dumb-phones-social-media/",
									children: "Fortune on Bloom and Brick"
								}),
								"."
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ContentSection, {
					id: "policy",
					title: "Policy is moving against the engagement model",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Governments and courts are increasingly targeting how platforms are designed: infinite scroll, autoplay, push notifications and engagement-optimised recommenders." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 overflow-x-auto rounded-2xl border",
							style: { borderColor: "rgba(13,27,42,0.16)" },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "min-w-[720px] w-full border-collapse text-left",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("caption", {
										className: "sr-only",
										children: "Recent policy action on social-media design"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										style: { background: "rgba(13,27,42,0.06)" },
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-5",
												scope: "col",
												children: "Date"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-5",
												scope: "col",
												children: "Where"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-5",
												scope: "col",
												children: "What happened"
											})
										] })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: policyTimeline.map(([date, place, event]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t",
										style: { borderColor: "rgba(13,27,42,0.12)" },
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "p-5 align-top whitespace-nowrap",
												children: date
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-5 align-top",
												scope: "row",
												children: place
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "p-5 align-top",
												children: event
											})
										]
									}, `${date}-${place}`)) })
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 overflow-x-auto rounded-2xl border",
							style: { borderColor: "rgba(13,27,42,0.16)" },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "min-w-[680px] w-full border-collapse text-left",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("caption", {
										className: "sr-only",
										children: "What regulators target and what Atlus does instead"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										style: {
											background: "var(--color-royal)",
											color: "white"
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "p-5",
											scope: "col",
											children: "What regulators are targeting"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "p-5",
											scope: "col",
											children: "What Atlus does instead"
										})] })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComparisonRow, {
											left: "Infinite scroll",
											right: "A finite daily edition: Light (1), Standard (3), or Deep (5) articles."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComparisonRow, {
											left: "Autoplay",
											right: "Nothing plays; readers choose what to open."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComparisonRow, {
											left: "Notifications engineered to pull people back",
											right: "One daily dispatch."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComparisonRow, {
											left: "Opaque, engagement-optimised recommenders",
											right: "Stated preferences, with a reason shown for every pick."
										})
									] })
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 text-2xl leading-snug",
							style: { fontFamily: "var(--font-display)" },
							children: "Atlus is aligned with where regulation is heading, not where it has been."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 text-sm opacity-70",
							children: [
								"Sources:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
									href: "https://digital-strategy.ec.europa.eu/en/news/commission-preliminarily-finds-tiktoks-addictive-design-breach-digital-services-act",
									children: "European Commission on TikTok"
								}),
								",",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
									href: "https://www.npr.org/2026/03/25/nx-s1-5746125/meta-youtube-social-media-trial-verdict",
									children: "NPR on the Los Angeles verdict"
								}),
								", and",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
									href: "https://techcrunch.com/2026/04/08/social-media-ban-children-countries-list",
									children: "TechCrunch country tracker"
								}),
								"."
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ContentSection, {
					id: "research",
					title: "The research behind Atlus",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-5 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
								title: "Milli et al., 2025",
								children: "Engagement ranking amplified emotionally charged, hostile political content that users said made them feel worse. Ranking by stated preference reduced angry, partisan and hostile content."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
								title: "Kim, Buntain & Ciampaglia, 2026",
								children: "Young adults said they wanted high-quality news but often engaged with lower-quality posts. Their stated-preference feeds were rated more satisfying and higher quality."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 text-2xl leading-snug",
							style: { fontFamily: "var(--font-display)" },
							children: "What people click and what people want are different things. Atlus builds for what they want."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/science/stated-preference-feed",
							className: "mt-7 inline-flex rounded-full px-6 py-3 text-sm font-semibold tracking-wide transition-transform hover:-translate-y-0.5 motion-reduce:transition-none motion-reduce:hover:translate-y-0 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4",
							style: {
								background: "var(--color-royal)",
								color: "white"
							},
							children: "Read the research →"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContentSection, {
					id: "sources",
					title: "Sources",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "space-y-4 text-base leading-relaxed",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
								href: "https://reutersinstitute.politics.ox.ac.uk/digital-news-report/2026/dnr-executive-summary",
								children: "Reuters Institute, Digital News Report 2026"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
								href: "https://academic.oup.com/pnasnexus/article/4/3/pgaf062/8052060",
								children: "Milli et al. (2025), PNAS Nexus"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
								href: "https://arxiv.org/abs/2604.11517",
								children: "Kim, Buntain & Ciampaglia (2026), arXiv preprint"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
								href: "https://www.pnas.org/doi/10.1073/pnas.2213114120",
								children: "Grüning, Riedel & Lorenz-Spreen (2023), PNAS"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
									href: "https://www.revenuecat.com/blog/growth/kenneth-schlenker-sub-club-podcast-2026",
									children: "RevenueCat on Opal growth"
								}),
								",",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
									href: "https://fortune.com/2026/02/13/analog-gen-z-phone-addiction-bloom-brick-app-blockers-dumb-phones-social-media/",
									children: "Fortune on Bloom and Brick"
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
								href: "https://digital-strategy.ec.europa.eu/en/news/commission-preliminarily-finds-tiktoks-addictive-design-breach-digital-services-act",
								children: "European Commission on TikTok’s addictive design"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
									href: "https://www.npr.org/2026/03/25/nx-s1-5746125/meta-youtube-social-media-trial-verdict",
									children: "NPR on the Los Angeles verdict"
								}),
								",",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
									href: "https://www.cnbc.com/2026/07/15/social-media-ban-uk-midnight-curfews-infinite-scroll-teens.html",
									children: "CNBC on UK proposals"
								}),
								", and",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceLink, {
									href: "https://techcrunch.com/2026/04/08/social-media-ban-children-countries-list",
									children: "TechCrunch country tracker"
								})
							] })
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-24 rounded-3xl px-7 py-12 text-center sm:px-12",
					style: {
						background: "var(--color-royal)",
						color: "white"
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-4xl",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 700
							},
							children: "Read with more intention."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto mt-4 max-w-xl text-lg leading-relaxed opacity-80",
							children: "A small daily paper, chosen with you in mind."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/#join",
							className: "mt-7 inline-flex rounded-full px-6 py-3 text-sm font-semibold tracking-wide",
							style: {
								background: "var(--color-amber)",
								color: "var(--color-royal)"
							},
							children: "Start onboarding"
						})
					]
				})
			]
		})
	});
}
function ContentSection({ id, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id,
		className: "mt-24 scroll-mt-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-8 text-[clamp(2rem,4vw,3.4rem)] leading-tight",
			style: {
				fontFamily: "var(--font-display)",
				fontWeight: 700
			},
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-lg leading-relaxed",
			children
		})]
	});
}
function StatCard({ stat, meaning }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl p-6",
		style: { background: "white" },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-5xl leading-none",
			style: {
				color: "var(--color-amber)",
				fontFamily: "var(--font-display)",
				fontWeight: 800
			},
			children: stat
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-base leading-relaxed opacity-80",
			children: meaning
		})]
	});
}
function Fact({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border p-6",
		style: {
			borderColor: "rgba(13,27,42,0.16)",
			background: "white"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-2xl leading-tight",
			style: {
				fontFamily: "var(--font-display)",
				fontWeight: 700
			},
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-base leading-relaxed opacity-80",
			children
		})]
	});
}
function ComparisonRow({ left, right }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-t",
		style: { borderColor: "rgba(13,27,42,0.12)" },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
			className: "p-5 align-top",
			scope: "row",
			children: left
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
			className: "p-5 align-top",
			children: right
		})]
	});
}
function SourceLink({ href, dark = false, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href,
		target: "_blank",
		rel: "noopener",
		className: "underline decoration-1 underline-offset-4",
		style: { color: dark ? "var(--color-platinum)" : "var(--color-amber)" },
		children
	});
}
export { WhyNowPage as component };
