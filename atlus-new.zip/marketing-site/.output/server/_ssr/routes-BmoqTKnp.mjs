import { __toESM } from "./rolldown-runtime-DDijeYup.mjs";
import { Link, require_jsx_runtime, require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { gsapWithCSS } from "../_libs/gsap.mjs";
import { HERO_MOTION, Handwriting, SiteFooter, SiteHeader, writeHandwriting } from "./router-BzoSQJH-.mjs";
import { CurvedArrow, DoubleUnderline, PhotoCircle } from "./marks-Drzm8awT.mjs";
// node_modules/.nitro/vite/services/ssr/assets/routes-BmoqTKnp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var stories = [
	{
		category: "Core",
		publication: "The Guardian",
		title: "Canada is seeking new global neighbours – no wonder, as Trump rolls out stupidities at scale",
		url: "https://www.theguardian.com/commentisfree/2026/sep/21/canada-donald-trump-mark-carney-global-eu",
		reason: "Chosen because of your strong interest in geopolitics.",
		number: "01"
	},
	{
		category: "Stretch",
		publication: "Quanta Magazine",
		title: "An Early Step on the Long, Strange Road to Photosynthesis",
		url: "https://www.quantamagazine.org/an-early-step-on-the-long-strange-road-to-photosynthesis-20260610/",
		reason: "You follow energy and climate policy. This takes you deeper into the biology that first made sunlight usable as energy on Earth.",
		number: "02"
	},
	{
		category: "Discovery",
		publication: "Works in Progress",
		title: "Why science needs outsiders",
		url: "https://worksinprogress.co/issue/why-science-needs-outsiders/",
		reason: "You haven't asked for science policy, but this argument about expertise and fresh perspectives may change how you think about institutions.",
		number: "03"
	}
];
var fragments = [
	"A changing world",
	"Ideas worth exploring",
	"Another point of view",
	"Science & discovery",
	"Beyond the headlines",
	"Culture & curiosity"
];
/** A finite editorial sequence: a world of stories becomes The Daily Atlus. */
function AnimatedHero({ ctas, showIntroduction = true, showEdition = true }) {
	const rootRef = (0, import_react.useRef)(null);
	const stageRef = (0, import_react.useRef)(null);
	const timelineRef = (0, import_react.useRef)(null);
	const replayRef = (0, import_react.useRef)(null);
	(0, import_react.useLayoutEffect)(() => {
		const root = rootRef.current;
		const stage = stageRef.current;
		if (!stage) return;
		const media = gsapWithCSS.matchMedia();
		media.add({
			motion: "(prefers-reduced-motion: no-preference)",
			reduced: "(prefers-reduced-motion: reduce)"
		}, (context) => {
			if (context.conditions?.reduced) {
				root.dataset.motion = "reduced";
				return () => {
					delete root.dataset.motion;
				};
			}
			const select = gsapWithCSS.utils.selector(root);
			const cards = select(".edit-story");
			const noise = select(".story-fragment");
			const placements = HERO_MOTION.cardPoses;
			root.dataset.motion = "ready";
			const timeline = gsapWithCSS.timeline({
				paused: true,
				onStart: () => {
					root.dataset.motion = "playing";
				},
				onComplete: () => {
					root.dataset.motion = "complete";
				}
			});
			timeline.timeScale(HERO_MOTION.playbackRate);
			timelineRef.current = timeline;
			Object.entries(HERO_MOTION.beats).forEach(([name, time]) => timeline.addLabel(name, time));
			timeline.fromTo(noise, {
				opacity: 0,
				y: 12
			}, {
				opacity: .45,
				y: 0,
				duration: .65,
				stagger: .055,
				ease: "power2.out"
			}, 0);
			cards.forEach((card, index) => {
				timeline.fromTo(card, {
					...placements[index],
					opacity: 0,
					scale: .98
				}, {
					...placements[index],
					opacity: 1,
					scale: 1,
					duration: .85,
					ease: "power3.out"
				}, .2 + index * .14);
			});
			timeline.fromTo(select(".edit-thread"), {
				strokeDashoffset: 1,
				opacity: .65
			}, {
				strokeDashoffset: 0,
				opacity: .65,
				duration: 1.1,
				ease: "power2.inOut"
			}, .6);
			timeline.to(noise, {
				opacity: 0,
				y: -8,
				duration: .55,
				stagger: .035,
				ease: "power2.inOut"
			}, "select");
			timeline.fromTo(select(".edit-paper"), {
				opacity: 0,
				scale: .99
			}, {
				opacity: 1,
				scale: 1,
				duration: 1,
				ease: "power3.out"
			}, "frame");
			timeline.to(cards, {
				x: 0,
				y: 0,
				rotation: 0,
				scale: 1,
				duration: 1.25,
				stagger: .12,
				ease: "power3.inOut"
			}, "arrange");
			timeline.fromTo(select(".edit-masthead"), {
				opacity: 0,
				y: 8
			}, {
				opacity: 1,
				y: 0,
				duration: .7,
				ease: "power2.out"
			}, "masthead");
			writeHandwriting(timeline, root.querySelector(".edit-for-you"), "masthead+=0.2");
			timeline.to(select(".edit-thread"), {
				opacity: 0,
				duration: .5
			}, "arrange+=0.6");
			timeline.fromTo(select(".story-reason"), {
				opacity: 0,
				y: 5
			}, {
				opacity: 1,
				y: 0,
				duration: .6,
				stagger: .12,
				ease: "power2.out"
			}, "explain");
			timeline.fromTo(select(".edit-finish"), {
				opacity: 0,
				y: 6
			}, {
				opacity: 1,
				y: 0,
				duration: .65,
				ease: "power2.out"
			}, "finish");
			timeline.fromTo(select(".edit-check"), { strokeDashoffset: 1 }, {
				strokeDashoffset: 0,
				duration: .4,
				ease: "power2.out"
			}, "check");
			const replay = gsapWithCSS.timeline({ paused: true }).to(stage, {
				opacity: 0,
				duration: .16,
				ease: "power1.out"
			}).call(() => timeline.restart()).to(stage, {
				opacity: 1,
				duration: .3,
				ease: "power1.out"
			});
			replayRef.current = replay;
			const observer = new IntersectionObserver(([entry]) => {
				if (entry.isIntersecting) {
					timeline.play(0);
					observer.disconnect();
				}
			}, { threshold: HERO_MOTION.visibleThreshold });
			observer.observe(stage);
			return () => {
				observer.disconnect();
				timelineRef.current = null;
				replayRef.current = null;
				delete root.dataset.motion;
			};
		}, root);
		return () => media.revert();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: rootRef,
		className: `atlus-hero-layout${showIntroduction ? "" : " daily-atlus-dash"}${showEdition ? "" : " atlus-hero-layout--intro"}`,
		children: [
			showIntroduction && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hero-introduction",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "hero-title",
						"aria-label": "Start Atlus onboarding",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hero-word hero-join",
								"aria-hidden": "true",
								children: "Join"
							}),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "hero-word hero-atlus",
								"aria-hidden": "true",
								children: [
									"Atl",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handwriting, {
										text: "u",
										className: "hero-u"
									}),
									"s",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hero-signature",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DoubleUnderline, { w: 520 })
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hero-description",
						children: "A finite daily edition: three stories chosen from more than 250 sources, with a clear reason for every recommendation."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hero-actions",
						children: ctas
					})
				]
			}),
			showEdition && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
				className: "hero-edition",
				"aria-label": "An illustrative Daily Atlus with a Core, Stretch and Discovery story",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: stageRef,
					className: "edition-stage",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "edition-orbit",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "edition-orbit edition-orbit-inner",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "story-fragments",
							"aria-hidden": "true",
							children: fragments.map((fragment, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `story-fragment story-fragment-${index}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fragment }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})
								]
							}, fragment))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							className: "edition-thread",
							viewBox: "0 0 540 550",
							fill: "none",
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								className: "edit-thread",
								pathLength: "1",
								strokeDasharray: "1",
								d: "M18 335 C-35 80 454 -28 499 189 C538 352 116 464 68 277 C32 126 367 148 498 375",
								stroke: "var(--color-amber)",
								strokeWidth: "1.5"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "edit-paper",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "edit-masthead",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "edit-kicker",
								children: "THE DAILY ATLUS"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handwriting, {
								text: "made for you",
								mode: "hero",
								className: "edit-for-you"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "edition-stories",
							children: stories.map((story) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: `edit-story edit-story-${story.category.toLowerCase()}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "story-topline",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "story-category",
											children: story.category
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "story-topic",
											children: story.publication
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: story.url,
										target: "_blank",
										rel: "noopener",
										children: story.title
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "story-baseline",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "story-reason",
											children: story.reason
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "story-number",
											"aria-hidden": "true",
											children: story.number
										})]
									})
								]
							}, story.category))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "edit-finish",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								viewBox: "0 0 20 20",
								width: "18",
								height: "18",
								fill: "none",
								"aria-hidden": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									className: "edit-check",
									pathLength: "1",
									strokeDasharray: "1",
									d: "M3 10 L8 15 L17 5",
									stroke: "currentColor",
									strokeWidth: "1.6",
									strokeLinecap: "round",
									strokeLinejoin: "round"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "A wider view. Then get on with your day." })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
					className: "edition-caption",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "An illustrative Daily Atlus" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "hero-replay",
						type: "button",
						onClick: () => {
							if (replayRef.current?.isActive()) return;
							timelineRef.current?.pause();
							replayRef.current?.restart();
						},
						"aria-label": "Replay the Daily Atlus animation",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							viewBox: "0 0 20 20",
							width: "15",
							height: "15",
							fill: "none",
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								d: "M4 7a6 6 0 1 1-.2 5M4 3v4h4",
								stroke: "currentColor",
								strokeWidth: "1.4",
								strokeLinecap: "round",
								strokeLinejoin: "round"
							})
						}), "Replay"]
					})]
				})]
			}),
			showIntroduction && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				className: "hero-scroll-note",
				href: "#how",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Good stories. A wider world." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": "true",
					children: "↓"
				})]
			})
		]
	});
}
/** The brand's editorial introduction. The Daily Atlus lives in the solution section. */
function Hero15a() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "atlus-hero",
		"aria-label": "Welcome to Atlus",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedHero, {
			showEdition: false,
			ctas: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: "#join",
				className: "hero-primary-cta",
				children: ["Start onboarding ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": "true",
					children: "↗"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: "#how",
				className: "hero-secondary-cta",
				children: ["The solution ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": "true",
					children: "↓"
				})]
			})] })
		})
	});
}
var productUrl = "https://app.joinatlus.com".replace(/\/$/, "");
var joinUrl = `${productUrl}/login?mode=signup`;
var signInUrl = `${productUrl}/login`;
function LandingPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		style: {
			background: "var(--color-platinum)",
			color: "var(--color-royal)"
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { variant: "dark" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero15a, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Problem, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Solution, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceCarousel, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PracticalDetails, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Personalisation, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhyUs, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Explore, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JoinSection, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
function Section({ id, eyebrow, title, children, bg, color, className = "" }) {
	const onRoyal = (bg ?? "").includes("royal");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id,
		className: `px-6 py-24 sm:px-10 sm:py-32 ${className}`,
		style: {
			background: bg ?? "var(--color-platinum)",
			color: color ?? "var(--color-royal)",
			...onRoyal ? {} : { ["--color-amber"]: "var(--color-amber-ink)" }
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl",
			children: [
				eyebrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-sm tracking-[0.25em]",
					style: {
						fontFamily: "var(--font-serif)",
						color: "var(--color-amber)"
					},
					children: eyebrow.toUpperCase()
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-10 max-w-3xl text-[clamp(2rem,4.5vw,3.6rem)] leading-[1.05] tracking-tight",
					style: {
						fontFamily: "var(--font-display)",
						fontWeight: 700
					},
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-lg leading-relaxed",
					style: { fontFamily: "var(--font-serif)" },
					children
				})
			]
		})
	});
}
function Handwritten({ children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handwriting, {
		text: children,
		className: `hand ${className}`,
		style: {
			color: "var(--color-amber)",
			fontSize: "1.35em",
			lineHeight: 1
		}
	});
}
/** Adds one reveal class when an element first enters the viewport. */
function useViewportReveal() {
	const ref = import_react.useRef(null);
	const [revealed, setRevealed] = import_react.useState(false);
	import_react.useEffect(() => {
		const element = ref.current;
		if (!element) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			setRevealed(true);
			return;
		}
		const observer = new IntersectionObserver(([entry]) => {
			if (!entry.isIntersecting) return;
			setRevealed(true);
			observer.disconnect();
		}, { threshold: .22 });
		observer.observe(element);
		return () => observer.disconnect();
	}, []);
	return {
		ref,
		revealed
	};
}
function Problem() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
		eyebrow: "The problem",
		title: "The news is broken.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-3xl",
			children: "The journalism is often good. The way it reaches us is not. Three problems explain why so many people feel poorly informed, even when news is everywhere."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-12 grid gap-5 lg:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border p-6 sm:p-7",
					style: {
						borderColor: "rgba(13,27,42,0.14)",
						background: "white"
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-[0.2em] opacity-55",
							children: "01"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "mt-4 text-3xl leading-tight",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 700
							},
							children: [
								"It rewards ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handwritten, { children: "reaction" }),
								", not understanding."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-base leading-relaxed opacity-80",
							children: "Engagement ranking pushes angry, hostile content because it keeps people clicking, even when readers say that content makes them feel worse."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-sm opacity-65",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudyLink, {
								href: "https://academic.oup.com/pnasnexus/article/4/3/pgaf062/8052060",
								children: "Milli et al., PNAS Nexus (2025)"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border p-6 sm:p-7",
					style: {
						borderColor: "rgba(13,27,42,0.14)",
						background: "white"
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-[0.2em] opacity-55",
							children: "02"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "mt-4 text-3xl leading-tight",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 700
							},
							children: [
								"It mistakes ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handwritten, { children: "attention" }),
								" for approval."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-base leading-relaxed opacity-80",
							children: "People often open low-quality stories they do not endorse. A click shows what caught your eye, not what you value or want more of."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-sm opacity-65",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudyLink, {
								href: "https://arxiv.org/abs/2604.11517",
								children: "Kim, Buntain & Ciampaglia (2026 preprint)"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border p-6 sm:p-7",
					style: {
						borderColor: "rgba(13,27,42,0.14)",
						background: "white"
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-[0.2em] opacity-55",
							children: "03"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "mt-4 text-3xl leading-tight",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 700
							},
							children: [
								"It makes staying informed feel ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handwritten, { children: "exhausting" }),
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-base leading-relaxed opacity-80",
							children: "Forty-two per cent of people now sometimes or often avoid the news, while global trust has fallen to 37 per cent. More news has not created more confidence."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-sm opacity-65",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudyLink, {
								href: "https://reutersinstitute.politics.ox.ac.uk/digital-news-report/2026/dnr-executive-summary",
								children: "Reuters Institute Digital News Report 2026"
							})
						})
					]
				})
			]
		})]
	});
}
function StudyLink({ href, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href,
		target: "_blank",
		rel: "noopener",
		className: "underline decoration-1 underline-offset-4 transition-opacity hover:opacity-75 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4",
		children
	});
}
function Solution() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
		id: "how",
		eyebrow: "The solution",
		title: "Three stories. Chosen for you.",
		bg: "#F1E9DE",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-3xl",
				children: "Atlus is a finite daily edition: three articles selected to reflect what you care about, deepen what you want to learn, and introduce something worth discovering."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-8 max-w-3xl",
				children: [
					"It uses recommendation technology to serve the interests you name, not to maximise the time you spend scrolling. Each edition contains a ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Core" }),
					", ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Stretch" }),
					", and ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Discovery" }),
					" story."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 rounded-2xl px-5 py-7 sm:px-8",
				style: {
					background: "var(--color-royal)",
					["--color-amber"]: "var(--amber)"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-6 text-sm tracking-[0.25em]",
					style: {
						color: "var(--color-platinum)",
						fontFamily: "var(--font-serif)"
					},
					children: "THE DAILY ATLUS"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedHero, { showIntroduction: false })]
			})
		]
	});
}
var FEATURED_SOURCES = [
	{
		name: "Associated Press",
		logo: "https://commons.wikimedia.org/wiki/Special:FilePath/Associated_Press_logo_2012.svg"
	},
	{
		name: "Reuters",
		logo: "https://commons.wikimedia.org/wiki/Special:FilePath/Reuters_Logo.svg"
	},
	{
		name: "BBC News",
		logo: "https://commons.wikimedia.org/wiki/Special:FilePath/BBC_News_2022_(Alt).svg"
	},
	{
		name: "Financial Times",
		logo: "https://commons.wikimedia.org/wiki/Special:FilePath/Financial_Times_corporate_logo.svg"
	},
	{
		name: "The Economist",
		logo: "https://commons.wikimedia.org/wiki/Special:FilePath/The_Economist_Logo.svg"
	},
	{
		name: "The Guardian",
		logo: "https://cdn.simpleicons.org/theguardian/052962"
	},
	{
		name: "Works in Progress",
		logo: "https://worksinprogress.co/wip-image/uploads/2025/04/Logo.png"
	},
	{
		name: "Al Jazeera English",
		logo: "https://upload.wikimedia.org/wikipedia/commons/f/f2/Aljazeera_eng.svg"
	}
];
function SourceCarousel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
		eyebrow: "The sources",
		title: "A wider view starts with wider sources.",
		bg: "var(--color-royal)",
		color: "var(--color-platinum)",
		className: "overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-3xl opacity-80",
				children: "Our starting list mixes familiar institutions with specialist, independent and international publishers. Every outlet is reviewed before inclusion. We are developing a short political- perspective note for each source, so you can judge the source as well as the story."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "source-marquee mt-10",
				"aria-label": "A selection of Atlus sources",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "source-marquee__track",
					children: [false, true].map((duplicate) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "source-marquee__group",
						"aria-hidden": duplicate || void 0,
						children: FEATURED_SOURCES.map((source) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "source-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: source.logo,
								alt: `${source.name} logo`,
								className: "source-card__logo",
								loading: "lazy",
								decoding: "async",
								referrerPolicy: "no-referrer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "source-card__name",
								"aria-hidden": "true",
								children: source.name
							})]
						}, source.name))
					}, duplicate ? "duplicate" : "primary"))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 max-w-3xl text-sm opacity-70",
				children: "Political leaning is context, not a quality score. No outlet label can guarantee an individual article is impartial or accurate; we will publish each assessment with its basis and update it when the evidence changes."
			})
		]
	});
}
function PracticalDetails() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
		eyebrow: "The practical bit",
		title: "A daily habit, not another feed.",
		bg: "#F1E9DE",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-5 sm:grid-cols-2",
			children: [
				{
					eyebrow: "DELIVERY",
					title: "Once a day, in your inbox",
					body: "Choose the time it arrives. We recommend about 30 minutes after you wake up, when there is space to read but before the day runs away with you."
				},
				{
					eyebrow: "READING",
					title: "The publisher's full article",
					body: "Atlus sends you to the publisher's original article, not an AI summary. If a link is blocked for you, tell us so we can improve future picks."
				},
				{
					eyebrow: "PRICE",
					title: "Free",
					body: "Atlus costs nothing to use."
				},
				{
					eyebrow: "AVAILABILITY",
					title: "Start reading now",
					body: "Create an account, complete onboarding, and see your first recommendations on Today. Choose when your daily email arrives."
				}
			].map((detail) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border p-6 sm:p-7",
				style: {
					borderColor: "rgba(13,27,42,0.14)",
					background: "white"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.2em]",
						style: {
							color: "var(--color-amber)",
							fontFamily: "var(--font-serif)"
						},
						children: detail.eyebrow
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-3 text-2xl leading-tight",
						style: {
							fontFamily: "var(--font-display)",
							fontWeight: 700
						},
						children: detail.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-base leading-relaxed opacity-80",
						children: detail.body
					})
				]
			}, detail.eyebrow))
		})
	});
}
function Personalisation() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
		eyebrow: "Personalisation",
		title: "You set the direction.",
		bg: "var(--color-royal)",
		color: "var(--color-platinum)",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "max-w-3xl",
				children: [
					"The Atlus onboarding process lets ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handwritten, { children: "you" }),
					" tell",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handwritten, { children: "us" }),
					" what you want, in an intuitive way."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-6 sm:grid-cols-3",
				children: [
					{
						k: "Preferences",
						body: "what you actually enjoy reading."
					},
					{
						k: "Goals",
						body: "what you want to understand better."
					},
					{
						k: "Knowledge",
						body: "what you already know, so we don't repeat it."
					}
				].map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border p-6",
					style: {
						borderColor: "rgba(248,249,250,0.22)",
						background: "white",
						color: "var(--color-royal)"
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-3 text-sm tracking-[0.25em] opacity-70",
							style: { fontFamily: "var(--font-serif)" },
							children: ["0", i + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mb-3 text-3xl",
							style: {
								fontFamily: "var(--font-display)",
								fontWeight: 700
							},
							children: c.k
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "opacity-80",
							children: c.body
						})
					]
				}, c.k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-16 max-w-3xl text-lg opacity-80",
				children: "Every assumption Atlus makes about you is visible and adjustable. Every recommendation also carries a short explanation: the interest it maps to, the goal it answers, or the new perspective it introduces. If it misses the mark, tell us and correct it."
			})
		]
	});
}
function WhyUs() {
	const { ref, revealed } = useViewportReveal();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
		eyebrow: "Why us",
		title: "Two perspectives, one purpose.",
		bg: "#F1E9DE",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
				ref,
				className: `why-us-pop relative mx-auto mt-10 max-w-4xl overflow-hidden rounded-2xl${revealed ? " is-revealed" : ""}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/founders.jpg",
						alt: "Sam Oliver and Henry Hudson with friends at a Durham formal.",
						className: "founders-photo aspect-[4/3] w-full object-cover",
						loading: "lazy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UniversityMarks, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/josephine-butler-college-crest-transparent.png",
						alt: "Josephine Butler College crest",
						className: "butler-crest",
						loading: "lazy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoCircle, {
						x: "65%",
						y: "56%",
						w: "15%",
						h: "24%",
						label: "Sam",
						labelPosition: "above",
						color: "var(--amber)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoCircle, {
						x: "52%",
						y: "53%",
						w: "15%",
						h: "24%",
						label: "Henry",
						labelPosition: "above",
						color: "var(--amber)"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 max-w-3xl",
				children: "We are building Atlus for a problem our generation lives with. Sam brings editorial context, economic history and natural-language processing; Henry brings computer science, machine learning and experience working on news recommendation systems. Together, that gives Atlus both a point of view about healthier news and the technical ability to build it."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 grid gap-8 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl p-8",
					style: {
						background: "var(--color-royal)",
						color: "var(--color-platinum)"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-2xl",
						style: {
							fontFamily: "var(--font-display)",
							fontWeight: 700
						},
						children: "Sam Oliver, CEO & Co-founder"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-base leading-relaxed opacity-80",
						children: "First-Class Honours in History from Durham University, focused on economic history and natural-language processing. Participant in the Durham Venture School accelerator."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl p-8",
					style: {
						background: "var(--color-royal)",
						color: "var(--color-platinum)"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-2xl",
						style: {
							fontFamily: "var(--font-display)",
							fontWeight: 700
						},
						children: "Henry B. Hudson, CTO & Co-founder"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-base leading-relaxed opacity-80",
						children: [
							"First-Class Honours in Computer Science from Durham University. Incoming MPhil in Machine Learning and Machine Intelligence at Cambridge. Previously worked on recommendation systems at News UK for ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "The Sun" }),
							" and ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "The Times" }),
							"."
						]
					})]
				})]
			})
		]
	});
}
function UniversityMarks() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "university-marks",
		"aria-label": "University affiliations",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/images/durham-university-wordmark.png",
			alt: "Durham University",
			className: "university-mark university-mark--durham",
			loading: "lazy"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/images/cambridge-university-wordmark.jpeg",
			alt: "University of Cambridge",
			className: "university-mark university-mark--cambridge",
			loading: "lazy"
		})]
	});
}
function Explore() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
		id: "explore",
		eyebrow: "Go deeper",
		title: "Read the thinking behind the paper.",
		bg: "var(--color-royal)",
		color: "var(--color-platinum)",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-3xl",
			children: "Atlus is built around a simple question: what would news feel like if it followed the interests you name, rather than the impulses a feed can measure? Explore the research, product principles and practical details."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-12 grid gap-5 sm:grid-cols-2",
			children: [
				{
					to: "/science/stated-preference-feed",
					eyebrow: "Research",
					title: "The stated-preference feed",
					body: "Why a news feed built around what you say you want can lead somewhere better than one built around clicks."
				},
				{
					to: "/privacy",
					eyebrow: "Privacy",
					title: "Personalisation, kept personal",
					body: "What reader information is for, and why it is never a product to be sold."
				},
				{
					to: "/faq",
					eyebrow: "Questions",
					title: "A few useful answers",
					body: "The essentials about Atlus, its daily edition and how recommendations work."
				},
				{
					to: "/manifesto",
					eyebrow: "Our view",
					title: "The Atlus manifesto",
					body: "Why the feed needs a new purpose, and the principles behind a healthier daily paper."
				}
			].map((page) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: page.to,
				className: "group flex min-h-56 flex-col justify-between rounded-2xl border p-6 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4",
				style: {
					borderColor: "rgba(13,27,42,0.16)",
					background: "white",
					color: "var(--color-royal)"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.2em]",
						style: {
							color: "var(--color-amber)",
							fontFamily: "var(--font-serif)"
						},
						children: page.eyebrow.toUpperCase()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-4 text-3xl leading-tight",
						style: {
							fontFamily: "var(--font-display)",
							fontWeight: 700
						},
						children: page.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-base leading-relaxed opacity-80",
						children: page.body
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mt-6 inline-flex items-center gap-2 text-sm font-semibold underline decoration-1 underline-offset-4",
					children: [
						"Read more",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							className: "transition-transform group-hover:translate-x-1 motion-reduce:transition-none motion-reduce:group-hover:translate-x-0",
							children: "→"
						})
					]
				})]
			}, page.to))
		})]
	});
}
function JoinSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "join",
		className: "relative px-6 py-32 sm:px-10",
		style: {
			background: "var(--color-platinum)",
			color: "var(--color-royal)",
			["--color-amber"]: "var(--color-amber-ink)"
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-4 flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CurvedArrow, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mb-6 text-[clamp(2.4rem,6vw,4.4rem)] leading-[1]",
					style: {
						fontFamily: "var(--font-display)",
						fontWeight: 800
					},
					children: [
						"Join",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative inline-block",
							children: [
								"Atl",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handwriting, {
									text: "u",
									className: "brand-u",
									style: { color: "var(--color-amber)" }
								}),
								"s"
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handwriting, {
					text: "begin with what matters to you",
					className: "mb-10 block text-2xl",
					style: { color: "var(--color-amber)" }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: joinUrl,
					className: "inline-flex min-h-11 items-center justify-center rounded-full px-7 py-3 text-sm font-semibold tracking-wide transition-opacity hover:opacity-85",
					style: {
						background: "var(--color-royal)",
						color: "var(--color-platinum)",
						fontFamily: "var(--font-serif)"
					},
					children: [
						"Join Atlus",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2",
							"aria-hidden": "true",
							children: "↗"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm opacity-60",
					style: { fontFamily: "var(--font-serif)" },
					children: "No endless feed. No selling your data. Three stories, then you're done."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm",
					style: { fontFamily: "var(--font-serif)" },
					children: [
						"Already have an account?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "underline underline-offset-4",
							href: signInUrl,
							children: "Sign in"
						})
					]
				})
			]
		})
	});
}
export { LandingPage as component };
