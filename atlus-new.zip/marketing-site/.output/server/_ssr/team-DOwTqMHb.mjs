import { require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { Page } from "./router-BzoSQJH-.mjs";
// node_modules/.nitro/vite/services/ssr/assets/team-DOwTqMHb.js
var import_jsx_runtime = require_jsx_runtime();
var people = [{
	name: "Samuel Oliver",
	role: "Co-founder · Editorial & Product",
	body: "First-Class Honours in History from Durham University, with a focus on economic history and natural language processing. Incoming participant in the Durham Venture School accelerator for 2026 to 2027.",
	initials: "SO"
}, {
	name: "Henry Hudson",
	role: "Co-founder · Machine Learning",
	body: "First-Class Honours in Computer Science from Durham University. Incoming MPhil in Machine Learning and Machine Intelligence at the University of Cambridge. Founder and leader of the British Algorithmic Olympiad; previously worked in recommendation at News UK for The Sun and The Times.",
	initials: "HH"
}];
function TeamPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		headerVariant: "light",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-6 pb-24 pt-40 sm:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-sm tracking-[0.25em]",
					style: {
						color: "var(--color-amber)",
						fontFamily: "var(--font-serif)"
					},
					children: "FOUNDING TEAM"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mb-10 text-[clamp(2.4rem,6vw,4.2rem)] leading-[1.02] tracking-tight",
					style: {
						fontFamily: "var(--font-display)",
						fontWeight: 800
					},
					children: "Two people, one paper."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "mb-14 overflow-hidden rounded-2xl",
					style: { background: "var(--color-royal)" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/founders.jpg",
						alt: "Sam Oliver and Henry Hudson with friends at a Durham formal.",
						className: "aspect-[4/3] w-full object-cover",
						fetchPriority: "high"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
						className: "px-5 py-4 text-sm leading-relaxed sm:px-6",
						style: {
							color: "var(--color-platinum)",
							fontFamily: "var(--font-serif)"
						},
						children: "Building Atlus from Durham, UK."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-10 sm:grid-cols-2",
					children: people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border p-8",
						style: {
							borderColor: "rgba(13,27,42,0.12)",
							background: "white"
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-6 flex h-24 w-24 items-center justify-center rounded-full",
								style: {
									background: "var(--color-royal)",
									color: "var(--color-platinum)",
									fontFamily: "var(--font-display)",
									fontWeight: 800,
									fontSize: "1.75rem",
									letterSpacing: "0.05em"
								},
								children: p.initials
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-3xl",
								style: {
									fontFamily: "var(--font-display)",
									fontWeight: 700,
									color: "var(--color-royal)"
								},
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm tracking-wide",
								style: {
									color: "var(--color-amber)",
									fontFamily: "var(--font-serif)"
								},
								children: p.role
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-base leading-relaxed opacity-80",
								style: {
									fontFamily: "var(--font-serif)",
									color: "var(--color-royal)"
								},
								children: p.body
							})
						]
					}, p.name))
				})
			]
		})
	});
}
export { TeamPage as component };
