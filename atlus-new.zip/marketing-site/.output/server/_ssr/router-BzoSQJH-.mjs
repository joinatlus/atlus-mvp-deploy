import { __exportAll, __toESM } from "./rolldown-runtime-DDijeYup.mjs";
import { HeadContent, Link, Outlet, Scripts, createFileRoute, createRootRoute, createRouter, lazyRouteComponent, require_jsx_runtime, require_react, useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { gsapWithCSS } from "../_libs/gsap.mjs";
// node_modules/.nitro/vite/services/ssr/assets/router-BzoSQJH-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-BfflqPoM.css";
var SITE_URL = "https://joinatlus.com";
var SITE_NAME = "Atlus";
var SOCIAL_IMAGE = `${SITE_URL}/og-atlus.png`;
function absoluteUrl(path) {
	return new URL(path, SITE_URL).toString();
}
/** Shared, crawlable metadata for every public page. */
function pageHead({ title, description, path, type = "website", socialTitle = title, socialDescription = description, structuredData }) {
	const url = absoluteUrl(path);
	return {
		meta: [
			{ title },
			{
				name: "description",
				content: description
			},
			{
				property: "og:title",
				content: socialTitle
			},
			{
				property: "og:description",
				content: socialDescription
			},
			{
				property: "og:type",
				content: type
			},
			{
				property: "og:url",
				content: url
			},
			{
				property: "og:site_name",
				content: SITE_NAME
			},
			{
				property: "og:locale",
				content: "en_GB"
			},
			{
				property: "og:image",
				content: SOCIAL_IMAGE
			},
			{
				property: "og:image:type",
				content: "image/png"
			},
			{
				property: "og:image:width",
				content: "2400"
			},
			{
				property: "og:image:height",
				content: "1260"
			},
			{
				property: "og:image:alt",
				content: "Atlus: daily news, personalised for you"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: socialTitle
			},
			{
				name: "twitter:description",
				content: socialDescription
			},
			{
				name: "twitter:image",
				content: SOCIAL_IMAGE
			},
			{
				name: "twitter:image:alt",
				content: "Atlus: daily news, personalised for you"
			}
		],
		links: [{
			rel: "canonical",
			href: url
		}],
		scripts: (structuredData ? Array.isArray(structuredData) ? structuredData : [structuredData] : []).map((schema) => ({
			type: "application/ld+json",
			children: JSON.stringify(schema)
		}))
	};
}
var siteStructuredData = {
	"@context": "https://schema.org",
	"@graph": [{
		"@type": "Organization",
		"@id": `${SITE_URL}/#organization`,
		name: SITE_NAME,
		url: SITE_URL,
		logo: SOCIAL_IMAGE,
		email: "sam@joinatlus.com",
		description: "Atlus is a small, deliberate daily paper that uses personalisation to widen readers' views.",
		contactPoint: {
			"@type": "ContactPoint",
			contactType: "customer support",
			email: "sam@joinatlus.com",
			availableLanguage: "en-GB"
		}
	}, {
		"@type": "WebSite",
		"@id": `${SITE_URL}/#website`,
		name: SITE_NAME,
		url: SITE_URL,
		publisher: { "@id": `${SITE_URL}/#organization` }
	}]
};
function webPageStructuredData(name, description, path) {
	return {
		"@context": "https://schema.org",
		"@type": "WebPage",
		name,
		description,
		url: absoluteUrl(path),
		isPartOf: { "@id": `${SITE_URL}/#website` },
		about: { "@id": `${SITE_URL}/#organization` }
	};
}
var HANDWRITING_MOTION = {
	enabled: true,
	start: "top 84%",
	delay: .22,
	letterDuration: .28,
	letterStagger: .06,
	maxDuration: 1.7,
	ease: "none",
	markDuration: .75,
	markStagger: .45
};
var HERO_MOTION = {
	playbackRate: .7,
	title: {
		liftPercent: 10,
		duration: .8,
		stagger: .12,
		ease: "power3.out"
	},
	writing: {
		uAt: .55,
		signatureAt: 1.05,
		taglineAt: 1.25,
		signatureDuration: .7
	},
	visibleThreshold: .25,
	cardPoses: [
		{
			x: -24,
			y: 18,
			rotation: -5
		},
		{
			x: 18,
			y: -10,
			rotation: 4
		},
		{
			x: -12,
			y: -28,
			rotation: -3
		}
	],
	beats: {
		arrive: 0,
		select: 1.35,
		arrange: 1.5,
		frame: 1.45,
		masthead: 2.15,
		explain: 2.75,
		finish: 3.3,
		check: 3.55
	}
};
/**
* The writing effect lives here. We reveal the ACTUAL font, not a replacement
* SVG drawing, so changing the words never requires redrawing paths.
* Negative vertical insets leave room for the font's tall and low strokes.
* No DOM is inserted by GSAP: React owns the letters, including cleanup.
*/
function writeHandwriting(timeline, element, at) {
	if (!element || !HANDWRITING_MOTION.enabled) return;
	const letters = element.querySelectorAll(".handwriting-letter");
	if (!letters.length) return;
	const stagger = Math.min(HANDWRITING_MOTION.letterStagger, Math.max(0, HANDWRITING_MOTION.maxDuration - HANDWRITING_MOTION.letterDuration) / Math.max(1, letters.length - 1));
	timeline.fromTo(letters, { clipPath: "inset(-35% 108% -35% -8%)" }, {
		clipPath: "inset(-35% -12% -35% -8%)",
		duration: HANDWRITING_MOTION.letterDuration,
		stagger,
		ease: HANDWRITING_MOTION.ease
	}, at);
}
/** One viewport trigger and pace for annotations and drawn marks. */
function useInkReveal(kind, enabled = true, delay = HANDWRITING_MOTION.delay, content = "") {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useLayoutEffect)(() => {
		const element = ref.current;
		if (!element || !enabled || !HANDWRITING_MOTION.enabled) return;
		const media = gsapWithCSS.matchMedia();
		media.add("(prefers-reduced-motion: no-preference)", () => {
			const timeline = gsapWithCSS.timeline({ paused: true }).timeScale(HERO_MOTION.playbackRate);
			if (kind === "text") writeHandwriting(timeline, element, delay);
			else element.querySelectorAll("path").forEach((path, index) => {
				const length = path.getTotalLength();
				timeline.fromTo(path, {
					strokeDasharray: length,
					strokeDashoffset: length
				}, {
					strokeDashoffset: 0,
					duration: HANDWRITING_MOTION.markDuration,
					ease: "power1.inOut"
				}, delay + index * HANDWRITING_MOTION.markStagger);
			});
			const observer = new IntersectionObserver(([entry]) => {
				if (!entry.isIntersecting) return;
				timeline.play();
				observer.disconnect();
			}, {
				threshold: 0,
				rootMargin: "0px 0px -8% 0px"
			});
			observer.observe(element);
			return () => observer.disconnect();
		}, element);
		return () => media.revert();
	}, [
		content,
		delay,
		enabled,
		kind
	]);
	return ref;
}
/**
* ANIMATED REENIE BEANIE — change `text` freely; letters update automatically.
* Example: <Handwriting text="chosen for you." />
* `mode="hero"` lets AnimatedHero own the timing; the default writes on scroll.
* `delay={0.4}` overrides the scroll delay for just this phrase.
* Layout is reserved from the first render. Screen readers get one intact phrase.
*/
function Handwriting({ text, className = "", style, mode = "scroll", delay }) {
	const rootRef = useInkReveal("text", mode !== "hero", delay, text);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		ref: rootRef,
		className: `handwriting ${className}`,
		style,
		"data-handwriting": mode,
		"data-writing-delay": delay,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: text
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": "true",
			children: text.split(/(\s+)/).map((word, wordIndex) => /\s/.test(word) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": "true",
				className: "handwriting-space",
				"data-space": word
			}, wordIndex) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "handwriting-word",
				children: Array.from(word).map((letter, letterIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "handwriting-letter",
					"data-letter": letter
				}, letterIndex))
			}, wordIndex))
		})]
	});
}
/** Shared lockup keeps the header and footer brand treatment identical. */
function AtlusWordmark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className,
		style: {
			fontFamily: "var(--font-display)",
			fontWeight: 800
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Atlus"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			"aria-hidden": "true",
			children: [
				"Atl",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handwriting, {
					text: "u",
					className: "brand-u",
					style: { color: "var(--color-amber)" }
				}),
				"s"
			]
		})]
	});
}
function SiteHeader({ variant = "light" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "absolute left-0 right-0 top-0 z-30 flex items-center justify-between px-6 py-5 sm:px-10",
		style: { color: variant === "dark" ? "var(--color-platinum)" : "var(--color-royal)" },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			"aria-label": "Atlus home",
			className: "flex min-h-11 items-center gap-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AtlusWordmark, { className: "text-2xl leading-none" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "flex items-center gap-6 text-sm",
			style: { fontFamily: "var(--font-serif)" },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/manifesto",
					className: "inline-flex min-h-11 items-center opacity-80 hover:opacity-100",
					children: "Manifesto"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/team",
					className: "inline-flex min-h-11 items-center opacity-80 hover:opacity-100",
					children: "Team"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "/#join",
					className: "inline-flex min-h-11 items-center rounded-full px-4 py-2 text-xs font-semibold tracking-wide",
					style: {
						background: "var(--color-amber)",
						color: "var(--color-royal)"
					},
					children: "Start"
				})
			]
		})]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "relative px-6 py-14 sm:px-10",
		style: {
			background: "var(--color-royal)",
			color: "var(--color-platinum)",
			["--color-amber"]: "var(--amber)"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col items-start justify-between gap-8 sm:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AtlusWordmark, { className: "text-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-sm text-sm opacity-70",
				style: { fontFamily: "var(--font-serif)" },
				children: "Daily news, personalised for you."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-10 text-sm",
				style: { fontFamily: "var(--font-serif)" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-xs uppercase tracking-widest opacity-60",
					children: "Read"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "-my-1 opacity-90",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "inline-flex min-h-11 items-center",
							children: "Home"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/manifesto",
							className: "inline-flex min-h-11 items-center",
							children: "Manifesto"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/why-now",
							className: "inline-flex min-h-11 items-center",
							children: "Why now"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/how-it-works",
							className: "inline-flex min-h-11 items-center",
							children: "How it works"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/team",
							className: "inline-flex min-h-11 items-center",
							children: "Team"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/faq",
							className: "inline-flex min-h-11 items-center",
							children: "FAQ"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/privacy",
							className: "inline-flex min-h-11 items-center",
							children: "Privacy"
						}) })
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-xs uppercase tracking-widest opacity-60",
					children: "Contact"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "-my-1 opacity-90",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "joinatlus.com" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "mailto:sam@joinatlus.com",
						className: "inline-flex min-h-11 items-center",
						children: "sam@joinatlus.com"
					}) })]
				})] })]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mx-auto mt-12 max-w-6xl text-xs opacity-50",
			style: { fontFamily: "var(--font-serif)" },
			children: [
				"© ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" Atlus. Your data personalises your edition and is never sold."
			]
		})]
	});
}
function Page({ children, headerVariant = "light" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen",
		style: {
			background: "var(--color-platinum)",
			color: "var(--color-royal)",
			["--color-amber"]: "var(--color-amber-ink)"
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { variant: headerVariant }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "absolute left-6 top-20 z-20 inline-flex items-center gap-2 text-sm underline decoration-1 underline-offset-4 opacity-75 transition-opacity hover:opacity-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 sm:left-10",
				style: { fontFamily: "var(--font-serif)" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": "true",
					children: "←"
				}), "Back to Atlus"]
			}),
			children,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
var socialImage = "https://joinatlus.com/og-atlus.png";
function FallbackHead({ title, description }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: title }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			name: "description",
			content: description
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			name: "robots",
			content: "noindex, nofollow"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			property: "og:title",
			content: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			property: "og:description",
			content: description
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			property: "og:type",
			content: "website"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			property: "og:site_name",
			content: "Atlus"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			property: "og:image",
			content: socialImage
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			property: "og:image:alt",
			content: "Atlus: daily news, personalised for you"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			name: "twitter:card",
			content: "summary_large_image"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			name: "twitter:title",
			content: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			name: "twitter:description",
			content: description
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			name: "twitter:image",
			content: socialImage
		})
	] });
}
function FallbackPage({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen",
		style: {
			background: "var(--color-platinum)",
			color: "var(--color-royal)"
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex min-h-[75vh] items-center justify-center px-6 pb-20 pt-32 sm:px-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-w-xl text-center",
					children
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
function NotFoundComponent() {
	const title = "Page not found | Atlus";
	const description = "That page is no longer here. Return to Atlus and keep exploring.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FallbackHead, {
		title,
		description
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FallbackPage, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-2xl",
			style: {
				color: "var(--color-amber-ink)",
				fontFamily: "var(--font-hand)"
			},
			children: "A wrong turn."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-3 text-[clamp(4.5rem,16vw,8rem)] font-bold leading-none",
			style: { fontFamily: "var(--font-display)" },
			children: "404"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-5 text-3xl font-semibold",
			style: { fontFamily: "var(--font-display)" },
			children: "Page not found"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto mt-4 max-w-md text-base opacity-70",
			children: description
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "mt-8 inline-flex min-h-11 items-center justify-center rounded-full px-6 py-3 text-sm font-semibold",
			style: {
				background: "var(--color-royal)",
				color: "var(--color-platinum)"
			},
			children: "Back to Atlus"
		})
	] })] });
}
function ErrorComponent({ reset }) {
	const router = useRouter();
	const title = "This page didn't load | Atlus";
	const description = "Atlus hit a temporary problem. Try the page again or return home.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FallbackHead, {
		title,
		description
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FallbackPage, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-2xl",
			style: {
				color: "var(--color-amber-ink)",
				fontFamily: "var(--font-hand)"
			},
			children: "Something went awry."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-4 text-4xl font-semibold",
			style: { fontFamily: "var(--font-display)" },
			children: "This page didn't load"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-base opacity-70",
			children: description
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 flex flex-wrap justify-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => {
					router.invalidate();
					reset();
				},
				className: "inline-flex min-h-11 items-center justify-center rounded-full px-6 py-3 text-sm font-semibold",
				style: {
					background: "var(--color-royal)",
					color: "var(--color-platinum)"
				},
				children: "Try again"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "inline-flex min-h-11 items-center justify-center rounded-full border px-6 py-3 text-sm font-semibold",
				style: { borderColor: "rgba(13,27,42,0.25)" },
				children: "Go home"
			})]
		})
	] })] });
}
var Route$8 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ "script:ld+json": siteStructuredData }
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.svg",
				type: "image/svg+xml"
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				sizes: "any"
			},
			{
				rel: "apple-touch-icon",
				href: "/apple-touch-icon.png",
				sizes: "180x180"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;0,800;1,600;1,700&family=PT+Serif:ital,wght@0,400;0,700;1,400&family=Reenie+Beanie&family=Caveat:wght@500;700&family=Kalam:wght@400;700&family=Permanent+Marker&family=Shantell+Sans:wght@500;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
}
var $$splitComponentImporter$7 = () => import("./routes-BmoqTKnp.mjs");
var Route$7 = createFileRoute("/")({
	head: () => pageHead({
		title: "Atlus: daily news, personalised for you",
		description: "Atlus is a small, deliberate daily paper. Personalisation that widens your view instead of narrowing it. Never sold. Never the feed.",
		path: "/",
		structuredData: webPageStructuredData("Atlus: daily news, personalised for you", "Atlus is a small, deliberate daily paper. Personalisation widens your view instead of narrowing it.", "/")
	}),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
/** Adds one reveal class when an element first enters the viewport. */
var questions = [
	{
		question: "What is Atlus?",
		answer: "Atlus is a personalised daily edition of three full-length articles, chosen around the interests you share, the subjects you want to understand, and worthwhile ideas outside your usual reading."
	},
	{
		question: "Where and when does Atlus arrive?",
		answer: "By email, once a day, at the time you choose. We recommend setting it for about 30 minutes after you wake up: early enough to shape your morning, but not the first thing you see."
	},
	{
		question: "Do I read full articles or Atlus summaries?",
		answer: "Full articles. Each recommendation links to the original publisher rather than replacing their reporting with an AI summary. Access can vary by publisher; tell us when an article is blocked so we can improve future picks."
	},
	{
		question: "What does Atlus cost?",
		answer: "Nothing. Atlus is free to use."
	},
	{
		question: "Can I start using Atlus now?",
		answer: "Yes. Create an account and complete onboarding to see your first recommendations on Today. You can also choose when your daily email arrives."
	},
	{
		question: "What happens when I start onboarding?",
		answer: "You tell Atlus about your interests, what you want to understand, what you already know, what to avoid, and when your email should arrive. You then review the profile Atlus has assembled and correct anything it has misunderstood."
	},
	{
		question: "What are Core, Stretch, and Discovery stories?",
		answer: "Core stories connect to subjects you already care about. Stretch stories help you move towards a subject you want to understand. Discovery stories introduce a useful perspective from beyond your usual reading."
	},
	{
		question: "How are the sources selected?",
		answer: "Founder Sam Oliver reviews each outlet before it enters the source list, looking at ownership, sourcing, editorial standards, corrections, and whether a piece is reporting, analysis, or opinion. The list mixes established publishers with specialist newsletters, independent writers, small outlets, and international journalism. We do not treat a political leaning as a reason to exclude otherwise sound journalism."
	},
	{
		question: "How does Atlus deal with political bias?",
		answer: "We make the source visible and are developing a short, sourced description of its broad political perspective to sit beside each recommendation. We also aim to prevent one viewpoint from dominating a reader's recommendations over time. An outlet label is context, not a claim that every article has the same slant, that a 'centre' outlet is unbiased, or that left/right predicts factual accuracy. If a source cannot sensibly be put on a left-right scale, we should say that rather than invent a label."
	},
	{
		question: "Can I exclude a publisher, subject, or political perspective?",
		answer: "Yes. Add it to your Avoid list during onboarding or later from your profile. An exclusion can be edited or removed whenever you change your mind."
	},
	{
		question: "Does Atlus learn from what I click?",
		answer: "Yes, but your explicit choices remain the foundation. Onboarding creates the first profile; the stories you open and the feedback you give then help Atlus refine it. Those changing assumptions remain visible and editable in your profile."
	},
	{
		question: "How does feedback change my next edition?",
		answer: "Feedback such as More like this, Less like this, Too basic, or Go further adjusts the relevant interests and knowledge in your profile. The next edition is selected using that updated picture of you."
	},
	{
		question: "What information does Atlus keep about me?",
		answer: "Your email, onboarding answers, delivery settings, exclusions, evolving recommendation profile, article opens, and direct feedback. It is kept while your account is active so Atlus can maintain your edition. You can inspect and change the information used to choose your articles, and delete your account and its data at any time. It is never sold."
	},
	{
		question: "How can I contact Atlus?",
		answer: "Email sam@joinatlus.com."
	}
];
var $$splitComponentImporter$6 = () => import("./faq-gNUEAI_D.mjs");
var title$4 = "Atlus FAQ: personalised daily news, explained";
var description$4 = "How Atlus delivers three free, personalised articles by email each day, chooses sources, learns from feedback, and protects reader data.";
var faqStructuredData = {
	"@context": "https://schema.org",
	"@type": "FAQPage",
	mainEntity: questions.map(({ question, answer }) => ({
		"@type": "Question",
		name: question,
		acceptedAnswer: {
			"@type": "Answer",
			text: answer
		}
	}))
};
var Route$6 = createFileRoute("/faq")({
	head: () => pageHead({
		title: title$4,
		description: description$4,
		path: "/faq",
		structuredData: faqStructuredData
	}),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./how-it-works-000yx-Tr.mjs");
var title$3 = "How Atlus works: a personalised daily news briefing";
var description$3 = "Atlus builds a small daily paper around the interests you share: core stories you care about, stretch stories to help you learn, and discovery stories to widen your view.";
var Route$5 = createFileRoute("/how-it-works")({
	head: () => pageHead({
		title: title$3,
		description: description$3,
		path: "/how-it-works",
		structuredData: webPageStructuredData(title$3, description$3, "/how-it-works")
	}),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./manifesto-CJXZpcY8.mjs");
var Route$4 = createFileRoute("/manifesto")({
	head: () => pageHead({
		title: "Manifesto — Atlus",
		description: "Recommendation systems should help people become who they aspire to be. The Atlus manifesto for a healthier relationship with the news.",
		path: "/manifesto",
		type: "article",
		structuredData: webPageStructuredData("Manifesto — Atlus", "The Atlus manifesto for a healthier relationship with the news.", "/manifesto")
	}),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./privacy-DDWz9DNx.mjs");
var title$2 = "Privacy at Atlus: personalisation without selling your data";
var description$2 = "Atlus is designed around information readers choose to share. It is used to improve their recommendations and is never sold.";
var Route$3 = createFileRoute("/privacy")({
	head: () => pageHead({
		title: title$2,
		description: description$2,
		path: "/privacy",
		structuredData: webPageStructuredData(title$2, description$2, "/privacy")
	}),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./team-DOwTqMHb.mjs");
var Route$2 = createFileRoute("/team")({
	head: () => pageHead({
		title: "Team — Atlus",
		description: "The founders behind Atlus — Samuel Oliver and Henry Hudson, building a healthier daily paper.",
		path: "/team",
		type: "profile",
		structuredData: webPageStructuredData("Team — Atlus", "The founders behind Atlus — Samuel Oliver and Henry Hudson, building a healthier daily paper.", "/team")
	}),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./why-now-Ccoj-WlN.mjs");
var title$1 = "Why now: the case for a finite news feed | Atlus";
var description$1 = "Audiences are turning away from engagement feeds, people are paying to scroll less, and regulators are targeting addictive design. Why Atlus is built for this moment.";
var path$1 = "/why-now";
var articleSchema$1 = {
	"@context": "https://schema.org",
	"@type": "Article",
	headline: "Why now: the case for a finite news feed",
	description: description$1,
	author: {
		"@type": "Organization",
		name: "Atlus"
	},
	publisher: {
		"@type": "Organization",
		name: "Atlus",
		url: "https://joinatlus.com",
		logo: {
			"@type": "ImageObject",
			url: "https://joinatlus.com/og-atlus.png"
		}
	},
	mainEntityOfPage: "https://joinatlus.com/why-now",
	datePublished: "2026-09-24",
	dateModified: "2026-09-24",
	citation: [
		"https://reutersinstitute.politics.ox.ac.uk/digital-news-report/2026/dnr-executive-summary",
		"https://academic.oup.com/pnasnexus/article/4/3/pgaf062/8052060",
		"https://arxiv.org/abs/2604.11517",
		"https://www.pnas.org/doi/10.1073/pnas.2213114120",
		"https://digital-strategy.ec.europa.eu/en/news/commission-preliminarily-finds-tiktoks-addictive-design-breach-digital-services-act"
	]
};
var Route$1 = createFileRoute("/why-now")({
	head: () => pageHead({
		title: title$1,
		description: description$1,
		path: path$1,
		type: "article",
		socialTitle: "The case for a finite news feed",
		socialDescription: "The audience is not done with news. It is done with the way the feed delivers it.",
		structuredData: articleSchema$1
	}),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var faqs = [
	{
		question: "What is a stated-preference feed?",
		answer: "A feed that ranks content by what readers explicitly say they want to read and learn, rather than by predicting what they will click. The term contrasts with revealed preference, which infers what you want from your behaviour.",
		citations: ["S1"]
	},
	{
		question: "Why do engagement-based feeds make people angry?",
		answer: "Because anger and hostility drive engagement. A preregistered audit of Twitter found its engagement algorithm amplified angry, hostile political content compared with a chronological feed, and users said this content made them feel worse about people on the other side.",
		citations: ["S1"]
	},
	{
		question: "Don't people just want the content they click on?",
		answer: "Not always. Research on inconsistent preferences shows that choices made in the moment often differ from what people actually want. When a recommender was tuned to people's ideal preferences, they clicked slightly less but felt better off.",
		citations: ["S2", "S3"]
	},
	{
		question: "Does a stated-preference feed create an echo chamber?",
		answer: "It can if it is the only signal. Research found that ranking purely by stated preference reduced exposure to opposing views. Atlus counters this with daily Stretch and Discovery picks outside your usual interests.",
		citations: ["S1"]
	},
	{
		question: "Why are so many people avoiding the news?",
		answer: "42% of people globally now sometimes or often avoid the news. The top reasons are its negative effect on mood and feeling worn out by the volume.",
		citations: ["S6", "S5"]
	},
	{
		question: "How is Atlus different from Apple News or Google News?",
		answer: "Atlus asks what you want to understand, gives you a small daily set of articles, and tells you why each one was chosen. Then it lets you stop.",
		citations: []
	}
];
var $$splitComponentImporter = () => import("./stated-preference-feed-D4iwhNbh.mjs");
var title = "The Stated-Preference Feed: News by What You Want | Atlus";
var description = "A stated-preference feed ranks news by what readers say they want, not what they click. The research on engagement algorithms, anger and news avoidance.";
var path = "/science/stated-preference-feed";
var articleSchema = {
	"@context": "https://schema.org",
	"@type": "Article",
	headline: "The Stated-Preference Feed: A feed built on what you want, not what you click",
	description: "A stated-preference feed ranks content by what readers say they want to read and learn, rather than by predicting what they will click, like or share.",
	author: {
		"@type": "Person",
		name: "Sam Oliver",
		jobTitle: "Co-founder, Atlus"
	},
	publisher: {
		"@type": "Organization",
		name: "Atlus",
		url: "https://joinatlus.com",
		logo: {
			"@type": "ImageObject",
			url: "https://joinatlus.com/og-atlus.png"
		}
	},
	mainEntityOfPage: "https://joinatlus.com/science/stated-preference-feed",
	datePublished: "2026-09-22",
	dateModified: "2026-09-22",
	citation: [
		"https://doi.org/10.1093/pnasnexus/pgaf062",
		"https://doi.org/10.1287/mnsc.2022.03683",
		"https://doi.org/10.1038/s41598-023-34192-x",
		"https://arxiv.org/abs/2604.11517",
		"https://arxiv.org/abs/2402.06831",
		"https://reutersinstitute.politics.ox.ac.uk/digital-news-report/2026/dnr-executive-summary"
	]
};
var definedTermSchema = {
	"@context": "https://schema.org",
	"@type": "DefinedTerm",
	name: "Stated-preference feed",
	description: "A content feed ranked by what readers explicitly say they want to read and learn, rather than by predicted engagement such as clicks, likes or shares.",
	url: "https://joinatlus.com/science/stated-preference-feed"
};
var faqSchema = {
	"@context": "https://schema.org",
	"@type": "FAQPage",
	mainEntity: faqs.slice(0, 5).map(({ question, answer }) => ({
		"@type": "Question",
		name: question,
		acceptedAnswer: {
			"@type": "Answer",
			text: answer
		}
	}))
};
var Route = createFileRoute("/science/stated-preference-feed")({
	head: () => pageHead({
		title,
		description,
		path,
		type: "article",
		socialTitle: "The Stated-Preference Feed",
		socialDescription: "Why ranking news by what you say you want beats ranking by what you click. The research, and its limits.",
		structuredData: [
			articleSchema,
			definedTermSchema,
			faqSchema
		]
	}),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$7.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$8
	}),
	FaqRoute: Route$6.update({
		id: "/faq",
		path: "/faq",
		getParentRoute: () => Route$8
	}),
	HowItWorksRoute: Route$5.update({
		id: "/how-it-works",
		path: "/how-it-works",
		getParentRoute: () => Route$8
	}),
	ManifestoRoute: Route$4.update({
		id: "/manifesto",
		path: "/manifesto",
		getParentRoute: () => Route$8
	}),
	PrivacyRoute: Route$3.update({
		id: "/privacy",
		path: "/privacy",
		getParentRoute: () => Route$8
	}),
	TeamRoute: Route$2.update({
		id: "/team",
		path: "/team",
		getParentRoute: () => Route$8
	}),
	WhyNowRoute: Route$1.update({
		id: "/why-now",
		path: "/why-now",
		getParentRoute: () => Route$8
	}),
	ScienceStatedPreferenceFeedRoute: Route.update({
		id: "/science/stated-preference-feed",
		path: "/science/stated-preference-feed",
		getParentRoute: () => Route$8
	})
};
var routeTree = Route$8._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
var getRouter = () => {
	return createRouter({
		routeTree,
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
export { HERO_MOTION, Handwriting, Page, SiteFooter, SiteHeader, faqs, questions, router_exports, useInkReveal, writeHandwriting };
