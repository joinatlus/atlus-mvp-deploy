import { require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { Handwriting, Page } from "./router-BzoSQJH-.mjs";
import { DoubleUnderline } from "./marks-Drzm8awT.mjs";
// node_modules/.nitro/vite/services/ssr/assets/manifesto-CJXZpcY8.js
var import_jsx_runtime = require_jsx_runtime();
function ManifestoPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		headerVariant: "light",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "mx-auto max-w-3xl px-6 pb-24 pt-40 sm:px-10",
			style: {
				fontFamily: "var(--font-serif)",
				color: "var(--color-royal)"
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-6 text-sm tracking-[0.25em]",
					style: { color: "var(--color-amber)" },
					children: "MANIFESTO"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mb-10 text-[clamp(2.4rem,6vw,4.2rem)] leading-[1.02] tracking-tight",
					style: {
						fontFamily: "var(--font-display)",
						fontWeight: 800
					},
					children: [
						"Remove the noise. Join",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative inline-block",
							children: [
								"Atl",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handwriting, {
									text: "u",
									className: "brand-u",
									style: { color: "var(--color-amber)" }
								}),
								"s",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pointer-events-none absolute left-0 top-[92%] w-full",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DoubleUnderline, { w: 260 })
								})
							]
						}),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "prose-lg space-y-6 text-lg leading-relaxed",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The feed was a good idea that outgrew its purpose. It began as a way to keep up with friends. Now it decides how most of the world learns what's happening, and it pushes news that is polemical, unverified and unchecked." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Mainstream news has been unfit for purpose for longer. It still produces seriously good journalism, but it competes for clicks, and clicks come from emotional headlines, not thoughtful reporting." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Atlus is built on a simple belief: the noise can be removed. The same recommendation systems that reward outrage can be redirected towards curiosity." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "border-l-4 pl-6 text-2xl italic",
							style: {
								borderColor: "var(--color-amber)",
								fontFamily: "var(--font-display)"
							},
							children: "\"Recommendation systems should help people become who they aspire to be.\""
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-base not-italic",
							style: { fontFamily: "var(--font-serif)" },
							children: "Sam Oliver, Co-founder"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The data we hold about you is yours to see and yours to change. We keep it for one purpose only: improving your recommendations." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Staying informed can be effortless and meaningful at the same time. That's why you should join Atlus." })
					]
				})
			]
		})
	});
}
export { ManifestoPage as component };
